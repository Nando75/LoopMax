import { translator, system, time, geo, reset, wifi, web } from './LoopMaxUtils.js';



export class Services {
    constructor(json = {}) {

        // Contenitore principale
        this.services = {};

        // Carica ogni servizio dinamicamente
        for (const [key, value] of Object.entries(json)) {
            this.services[key] = {
                name: value.name || key,
                icon: value.icon || "",
                state: value.state || "UNKNOWN",
                dependencies: Array.isArray(value.dependencies) ? value.dependencies : [],
                webCommands: Array.isArray(value.webCommands) ? value.webCommands : []
            };

            // Accesso diretto tipo this.conf, this.geo, ecc.
            this[key] = this.services[key];
        }
    }

    // Ritorna la lista dei nomi dei servizi
    list() {
        return Object.keys(this.services);
    }

    // Ritorna un servizio per nome
    get(name) {
        return this.services[name] || null;
    }

    // Ritorna i servizi in stato READY
    ready() {
        return Object.values(this.services).filter(s => s.state === "READY");
    }

    // Ritorna le dipendenze di un servizio
    dependenciesOf(name) {
        const svc = this.get(name);
        return svc ? svc.dependencies : [];
    }

    // Ritorna i comandi web di un servizio
    commandsOf(name) {
        const svc = this.get(name);
        return svc ? svc.webCommands : [];
    }



getHtml(filterState = "") {
    let svcs = Object.values(this.services);
    if (filterState) {
        svcs = svcs.filter(s => s.state === filterState);
    }

    const badgeForState = (state) => {
        const base = 'badge rounded-pill badge-sm me-4';
        switch (state) {
            case "READY": return `<span class="${base} bg-success">Ready</span>`;
            case "INITIALIZING": return `<span class="${base} bg-warning text-dark">Init</span>`;
            case "STOPPED": return `<span class="${base} bg-secondary">Stopped</span>`;
            case "ERROR": return `<span class="${base} bg-danger">Error</span>`;
            default: return `<span class="${base} bg-dark">${state}</span>`;
        }
    };



    const accordionId = "servicesAccordion";
    const items = svcs.map((svc, i) => {
        const collapseId = `collapse-${svc.name}`;
        const headingId = `heading-${svc.name}`;
        //const isFirst = i === 0 ? "show" : "";
        const isFirst = "";

        const depsHtml = svc.dependencies.length
            ? `<ul class="list-group list-group-sm mb-2">
                    ${svc.dependencies.map(dep => `<li class="list-group-item py-1 px-2">${dep}</li>`).join("")}
               </ul>`
            : `<div class="text-muted small" data-tr="lblNoDep"></div>`;

        const cmdsHtml = svc.webCommands.length
            ? `<ul class="list-group list-group-sm mb-2">
                    ${svc.webCommands.map(c => `<li class="list-group-item py-1 px-2">${c.method} ${c.uri}</li>`).join("")}
               </ul>`
            : `<div class="text-muted small" data-tr="lblNoCommands"></div>`;

        let extraHtml = "";
        if (svc.name.toLowerCase() === "system" && system()) { extraHtml = system().renderCard(); }
        if (svc.name.toLowerCase() === "timer" && time()) { extraHtml = time().renderCard(); }
        if (svc.name.toLowerCase() === "geo" && geo()) { extraHtml = geo().renderCard(); }
        if (svc.name.toLowerCase() === "reset" && reset()) { extraHtml = reset().renderCard(); }
        if (svc.name.toLowerCase() === "wifi" && wifi()) { extraHtml = wifi().renderCard(); }
        if (svc.name.toLowerCase() === "web" && web()) { extraHtml = web().renderCard(); }

        return `
        <div class="accordion-item">
            <h2 class="accordion-header" id="${headingId}">
                <button class="accordion-button ${isFirst ? "" : "collapsed"}" type="button" data-bs-toggle="collapse" data-bs-target="#${collapseId}" aria-expanded="${isFirst ? "true" : "false"}" aria-controls="${collapseId}">1
                    <div class="d-flex justify-content-between align-items-center w-100">
                        <span class="text-truncate secondFont">${svc.icon || "🧩"} ${svc.name.toUpperCase()}</span>
                        ${badgeForState(svc.state)}
                    </div>


                </button>
            </h2>
            <div id="${collapseId}" class="accordion-collapse collapse ${isFirst}" aria-labelledby="${headingId}" data-bs-parent="#${accordionId}">
                       <div class="accordion-body">
                        ${extraHtml}
                        <div class="mt-3 mb-2"><strong data-tr="lblState"></strong> ${svc.state}</div>
                        <div class="mb-2"><strong data-tr="lblDep"></strong> ${depsHtml}</div>
                        <div class="mb-2"><strong data-tr="lblWebCmd"></strong> ${cmdsHtml}</div>
                    </div>
            </div>
        </div>`;
    });

    const accordionHtml = svcs.length
        ? `<div class="accordion" id="${accordionId}">${items.join("")}</div>`
        : `<div class="text-muted">Nessun servizio corrispondente al filtro</div>`;

    // Wrapper completo con filtro + contenuto
    return `
        <div id="services-wrapper">
            <div id="services-filter" class="mb-3"></div>
            <div id="services-content">${accordionHtml}</div>
        </div>`;
}



renderStateSelect(containerId = "services-filter") {
    const container = document.getElementById(containerId);
    if (!container) return;

    const select = document.createElement("select");
    select.className = "form-select form-select-sm w-auto d-inline-block me-2";
    select.innerHTML = `
        <option value="">All</option>
        <option value="READY">✅ READY</option>
        <option value="INITIALIZING">⚙️ INIT</option>
        <option value="STOPPED">⏹ STOPPED</option>
        <option value="ERROR">❌ ERROR</option>
    `;

    select.addEventListener("change", () => {
        const selected = select.value;
        const html = this.getHtml(selected);
        const target = document.getElementById("services-content");
        if (target) 
        {
            target.innerHTML = html;
            translator.translateDiv(target.id);
        }
            
        //translator.translatePage();
    });

    container.innerHTML = `<label class="form-label me-2">Filtra stato:</label>`;
    container.appendChild(select);
}



}
