import { translator, toast, loader, wifi, setToken, clearToken, sendAPI, fetchAPI,  } from './LoopMaxUtils.js';

export class Login {
    constructor(LoopMaxCore) {
        this.core = LoopMaxCore;
    }

    getHtml(DevName)
    {
        this.wifi = wifi();
        

        const lblLogin = translator.tr("lblLogin");

        return `<div class="tab-pane fade show active" id="loginTab" role="tabpanel">
                <div class="d-flex justify-content-center align-items-center" style="min-height: 50vh;">
                    <div class="card shadow-lg border-0" style="max-width: 380px; width: 100%;">
                        <div class="card-body p-4">
                            <form id="loginForm" autocomplete="off">
                                    <!-- USER -->
                                    <div class="form-floating mb-3 KeyText textGlowOrange">
                                        ${DevName}
                                    </div>
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control glow-input" id="loginUser"
                                            placeholder="User" disabled value="${this.wifi.apSsid}">
                                        <label for="loginUser">User</label>
                                    </div>
                                    <!-- PASSWORD -->
                                    <div class="form-floating mb-3 position-relative">
                                        <input type="password" class="form-control glow-input" id="loginPass"
                                            placeholder="Password" required>
                                        <label for="loginPass">Password</label>
                                        <!-- toggle password -->
                                        <button type="button"
                                                class="btn btn-sm btn-outline-secondary position-absolute top-50 end-0 translate-middle-y me-2"
                                                id="togglePassword">
                                        👁
                                        </button>
                                    </div>
                                    <div class="d-grid">
                                        <button class="btn btn-primary fw-bold" type="submit" data-tr="lblLogin">${lblLogin}</button>
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
                </div>`;
    }


    initObjects()
    {
        const form = document.getElementById("loginForm");
        const togglePwd = document.getElementById("togglePassword");
        const passInput = document.getElementById("loginPass");

        // toggle password
        togglePwd?.addEventListener("click", () => {
            passInput.type = passInput.type === "password" ? "text" : "password";
        });

        // submit login
        form?.addEventListener("submit", async (e) => {
            e.preventDefault();
            this.login();
        });
    }

    async login() {
    loader(true);

    try {
        clearToken();

        const form = new URLSearchParams({
            usr: loginUser.value,
            psw: loginPass.value
        });

        const token = await sendAPI("web/login", {
            method: "POST",
            body: form.toString(),
            return: "text"
        });

        if (!/^[A-Za-z0-9]{10}$/.test(token)) {
            toast(translator.tr("lblLoginFailed"), "danger");
            return;
        }
        setToken(token);
        await this.core.loadPage();
    } catch (err) {
        console.error("LOGIN FAIL:", err);
        toast(translator.tr("lblLoginFailed"), "danger");
    } finally {
        loader(false);
    }
}



    async logout() {
        try {

            await fetchAPI('web/logout');
            clearToken();
        } catch (err) {
            console.error(err);
        } 

    }

}
