import { escapeHtml } from './LoopMaxUtils.js';

export class Modules {
    constructor(json = {}) {

        this.modules = {};

        for (const [, value] of Object.entries(json)) {

            // Usa SOLO il name interno, obbligatorio
            const moduleName = (value.Name || "").toLowerCase();

            if (!moduleName) {
                console.warn("Module with name blanck, ignored:", value);
                continue;
            }

            this.modules[moduleName] = {
                id: moduleName,
                Name: value.Name,
                Icon: value.Icon || "",
                JsonConfig: value.JsonConfig || "",
                JsUIClass: value.JsUIClass || "",
                DeviceName: value.DeviceName || "",
                Company: value.Company || "",
                Url: value.Url || "",
                Code: value.Code || "",
                FwVersion: value.FwVersion || "",
                newFwVersion: value.newFwVersion || "",
                UpdateAvalaible: !!value.UpdateAvalaible,
                Https_ApiUrl: value.Https_ApiUrl || "",
                Https_ShowData: !!value.Https_ShowData,
                Https_Port: value.Https_Port || 0,
                Https_TimeOut: value.Https_TimeOut || 0,
                Https_UseCA: !!value.Https_UseCA,
                Https_User: value.Https_User || "",
                Https_Psw: value.Https_Psw || "",
                
                Mqtts_Port: value.Mqtts_Port || 0,
                Mqtts_Psw: value.Mqtts_Psw || "",
                Mqtts_Server: value.Mqtts_Server || "",
                Mqtts_User: value.Mqtts_User || "",
                MqttPsw: value.MqttPsw || "",
                Mqtts_ShowData: !!value.Mqtts_ShowData,
                Mqtts_UseCA: !!value.Mqtts_UseCA,
                SaveConfig: !!value.SaveConfig,
                pins: Array.isArray(value.pins) ? value.pins : [],
                webCommands: Array.isArray(value.webCommands) ? value.webCommands : []

            };

            // Accesso diretto: this.zappy
            this[moduleName] = this.modules[moduleName];
        }
    }


        getFirst() {
            const keys = Object.keys(this.modules);
            if (!keys.length) return null;
            return this.modules[keys[0]];
        }

        getFirstName() {
            const first = this.getFirst();
            return first ? first.Name || "" : "";
        }



    list() {
        return Object.keys(this.modules);
    }

    get(name) {
        return this.modules[name.toLowerCase()] || null;
    }

 


    pinsOf(name) {
        const mod = this.get(name);
        return mod ? mod.pins : [];
    }

    updatePin(moduleName, pinNumber, level, pinName = null) {
        const mod = this.get(moduleName);
        if (!mod || !Array.isArray(mod.pins)) return false;
        const pin = mod.pins.find(p => p.number === pinNumber);
        if (!pin) return false;
        pin.level = level;
        if (pinName !== null) {
            pin.name = pinName;
        }
        return true;
    }


    commandsOf(name) {
        const mod = this.get(name);
        return mod ? mod.webCommands : [];
    }

    withUI() {
        return Object.values(this.modules).filter(m => m.uiResource);
    }




                getHtml() {
                    const mods = Object.values(this.modules);

                    if (mods.length === 0) {
                        return `<div class="text-muted">Nessun modulo disponibile</div>`;
                    }

                    const accordionId = "modulesAccordion";

                    const items = mods.map((mod, i) => {
                        const collapseId = `collapse-${mod.Name}`;
                        const headingId = `heading-${mod.Name}`;
                        const isFirst = i === 0 ? "show" : "";

                        const pinsHtml = this.rederPinStatus(mod.pins);

                        // Le due righe devono apparire SOLO se showData è true
                        const httpsData = mod.Https_ShowData
                            ? `<div class="mb-2"><strong>API:</strong>&nbsp;<code>${mod.Https_ApiUrl}</code></div>
                               <div class="mb-2"><strong>HTTPS:</strong> ${mod.Https_ShowData ? "✅" : "❌"} – CA: ${mod.Https_UseCA ? "✅" : "❌"} – Timeout: ${mod.Https_TimeOut ?? "?"} ms</div>`
                            : ``;

                        const mqttsData = mod.Mqtts_ShowData
                            ? `<div class="mb-2"><strong>MQTT:</strong> ${mod.Mqtts_ShowData ? "✅" : "❌"} – CA: ${mod.Mqtts_UseCA ? "✅" : "❌"} – Server: ${mod.Mqtts_Server || "-"}:${mod.Mqtts_Port || "-"}</div>`
                            : ``;

                        const cmdsHtml = mod.webCommands.length
                            ? `<ul class="list-group list-group-sm mb-2">
                                ${mod.webCommands.map(c => `<li class="list-group-item py-1 px-2">${c.method} ${c.uri}</li>`).join("")}
                            </ul>`
                            : `<div class="text-muted small">Nessun comando</div>`;
                        
                        const fwUpdate = mod.UpdateAvalaible
                            ? `<div class="mb-2 textGlow"><strong data-tr="lblUpdateFw"></strong>:&nbsp;${mod.newFwVersion}</div>`
                            : ``;
                        

                        return `
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="${headingId}">
                                    <button class="secondFont accordion-button ${isFirst ? "" : "collapsed"}" type="button" data-bs-toggle="collapse" data-bs-target="#${collapseId}" aria-expanded="${isFirst ? "true" : "false"}" aria-controls="${collapseId}">
                                        ${mod.Icon} ${mod.Name}
                                    </button>
                                </h2>

                                <div id="${collapseId}" class="accordion-collapse collapse ${isFirst}" aria-labelledby="${headingId}" data-bs-parent="#${accordionId}">
                                    <div class="accordion-body">
                                        <div class="mb-2"><strong data-tr="lblModName"></strong>&nbsp;${mod.Name}</div>
                                        <div class="mb-2"><strong data-tr="lblCode"></strong>&nbsp;${mod.Code}</div>
                                        <div class="mb-2"><strong data-tr="lblFirmVers"></strong>&nbsp;${mod.FwVersion}</div>
                                        ${fwUpdate}
                                        <div class="mb-2"><strong data-tr="lblCompany"></strong>&nbsp;<a href="${mod.Url}" target="_blank">${mod.Company}</a></div>
                                        ${httpsData}
                                        ${mqttsData}
                                        <div class="mb-2"><strong>Pins:</strong><div id="${mod.Name.toLowerCase()}_Pins">${pinsHtml}</div></div>
                                        <div class="mb-2"><strong data-tr="lblWebCmd"></strong> ${cmdsHtml}</div>
                                        <div class="mb-2"><div id="${mod.Name.toLowerCase()}_Payload">${this.renderPayload(mod.JsonConfig)}</div></div>
                                    </div>
                                </div>
                            </div>`;
                    });

                    return `<div class="accordion" id="${accordionId}">${items.join("")}</div>`;
                }



    rederPinStatus(pins)
    {
         return pins.length
                ? `<ul class="list-group list-group-sm mb-2">
                    ${pins.map(p => {
                        const badgeClass = p.level ? "bg-success" : "bg-danger";

                        return `
                            <li class="list-group-item d-flex justify-content-between align-items-center py-1 px-2">

                                <div class="d-flex align-items-center gap-2">

                                    <!-- Quadratino azzurro col numero pin -->
                                    <span class="badge bg-info text-dark rounded-1" 
                                        style="width:28px; height:22px; display:flex; align-items:center; justify-content:center;">
                                        ${p.number}
                                    </span>

                                    <!-- Nome pin più in risalto -->
                                    <span class="fw-semibold">${p.name}</span>
                                </div>

                                <!-- Badge livello -->
                                <span class="badge ${badgeClass} rounded-pill">L${p.level}</span>
                            </li>`;
                    }).join("")}
                </ul>`
                : `<div class="text-muted small">Nessun pin</div>`;


    }

    refreshPinStatus(moduleName, pins) {
        if (!moduleName) return;
        const divPins = document.getElementById(moduleName.toLowerCase() + "_Pins");
        if (!divPins) return;

        if (!Array.isArray(pins) || pins.length === 0) {
            divPins.innerHTML = `<div class="text-muted small">Nessun pin</div>`;
            return;
        }
        this.pins = pins;
        divPins.innerHTML =  this.rederPinStatus(pins);
    }


        refreshPayload(moduleName, payload) {
            if (!moduleName) return;
            const div = document.getElementById(moduleName.toLowerCase() + "_Payload");
            if (!div) return;
            if (!payload) return;
            let jsonString;
            if (typeof payload === "object") {
                jsonString = JSON.stringify(payload);
            } else if (typeof payload === "string") {
                jsonString = payload;
            } else {
                return;
            }
            this.payload = payload;
            div.innerHTML = this.renderPayload(payload);
        }




    
       renderPayload(pld) {
            if (!pld) return "";

            let jsonString;

            if (typeof pld === "object") {
                jsonString = JSON.stringify(pld);
            } else if (typeof pld === "string") {
                jsonString = pld;
            } else {
                return "";
            }

            if (jsonString.trim() === "{}") return "";

            let parsed;
            try {
                parsed = JSON.parse(jsonString);
            } catch (e) {
                return `<details class="mt-1"><summary class="text-danger">Payload (malformato)</summary><pre class="text-danger small">${escapeHtml(jsonString)}</pre></details>`;
            }

            const pretty = JSON.stringify(parsed, null, 2);
            return `
                <details class="mt-1" style="background-color: var(--bs-tertiary-bg); border-radius: .25rem; padding: .5rem;">
                    <summary class="text-muted small">Payload</summary>
                    <pre class="small border rounded p-2 mt-1" style="background-color: var(--bs-body-bg); color: var(--bs-body-color);">${escapeHtml(pretty)}</pre>
                </details>`;
        }





}
