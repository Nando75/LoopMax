import { registerTimer, setTextContent } from './LoopMaxUtils.js';

export class System {
    constructor(json) {
        this.debug = json.debug || false;
        this.name = json.name || "LoopMax";
        this.key = json.key || "";
        this.FwVersion = json.FwVersion || "1.0.0";
        this.Company = json.Company || "SmartiLab";
        this.url = json.url || "SmartiLab.it";
        this.core = json.core || 0;
        this.chipRevision = json.chipRevision || 0;
        this.cpuFreq = json.cpuFreq || 0;
        this.flashSize = json.flashSize || 0;
        this.flashSpeed = json.flashSpeed || 0;
        this.heapSize = json.heapSize || 0;
        this.heapFree = json.heapFree || 0;
        this.uptime = json.uptime || 0;
        this.chipModel = json.chipModel || "";
        this.mode = json.mode || "";
        this.api = json.api || "";
        this.apiVersion = json.apiVersion || "";
        this.logged = json.isLogged || false;
    
    }

    isLogged() {
        return this.logged || false;
    }

    getMode() {
        return this.mode || "AP";
    }
    
    isModeAp() {
        return this.mode === "AP";
    }
    isModeLan() {
        return this.mode === "LAN";
    }
  
    uptimeSeconds() {
        return this.uptime;
    }

    uptimeMinutes() {
        return Math.floor(this.uptime / 60);
    }

    summary() {
        return `${this.name} (${this.chipModel}) - FW ${this.FwVersion} - Mode: ${this.mode}`;
    }





        renderCard() {
                let _company = `<div class="col-6 text-end">${this.Company}</div>`;
                if(this.mode === "LAN" || this.mode === "CLOUD")
                   { _company = `<div class="col-6 text-end"><a href="${this.url}">${this.Company}</a></div>`; }

                let ApiInfo = "";
                if (this.mode == 'LAN') {
                        ApiInfo = `
                            <div class="row mb-2">
                                <div class="col-6"><strong>${this.name} Api</strong></div>
                                <div class="col-6 text-end">${this.api}</div>
                            </div><hr>
                            <div class="row mb-2">
                                <div class="col-6"><strong>Api vers.</strong></div>
                                <div class="col-6 text-end">${this.apiVersion}</div>
                            </div><hr>
                        `;
                    }

           
                registerTimer("system", this.onTick.bind(this));
                return `
                    <div class="card mt-3 shadow-sm">
                        <div class="card-header fw-bold">
                            System Info
                        </div>

                        <div class="card-body p-3">

                            <div class="row mb-2">
                                <div class="col-6"><strong data-tr="lblName"></strong></div>
                                <div class="col-6 text-end">${this.name}</div>
                            </div><hr>

                            <div class="row mb-2">
                                <div class="col-6"><strong data-tr="lblKey"></strong></div>
                                <div class="col-6 text-end">${this.key}</div>
                            </div><hr>

                            <div class="row mb-2">
                                <div class="col-6"><strong data-tr="lblFirmVers"></strong></div>
                                <div class="col-6 text-end">${this.FwVersion}</div>
                            </div><hr>

                            <div class="row mb-2">
                                <div class="col-6"><strong>Core</strong></div>
                                <div class="col-6 text-end">${this.core}</div>
                            </div><hr>
                            <div class="row">
                                <div class="col-6"><strong data-tr="lblChipModel"></strong></div>
                                <div class="col-6 text-end">${this.chipModel}</div>
                            </div><hr>

                            <div class="row mb-2">
                                <div class="col-6"><strong data-tr="lblChipRev"></strong></div>
                                <div class="col-6 text-end">${this.chipRevision}</div>
                            </div><hr>

                            <div class="row mb-2">
                                <div class="col-6"><strong>CPU Freq</strong></div>
                                <div class="col-6 text-end">${this.cpuFreq} MHz</div>
                            </div><hr>

                            <div class="row mb-2">
                                <div class="col-6"><strong data-tr="lblFlaSize"></strong></div>
                                <div class="col-6 text-end">${this.flashSize} MB</div>
                            </div><hr>

                            <div class="row mb-2">
                                <div class="col-6"><strong data-tr="lblFlaSpeed"></strong></div>
                                <div class="col-6 text-end">${this.flashSpeed} MHz</div>
                            </div><hr>

                            <div class="row mb-2">
                                <div class="col-6"><strong data-tr="lblHeapSize"></strong></div>
                                <div class="col-6 text-end">${this.heapSize/1024} Kb</div>
                            </div><hr>

                            <div class="row mb-2">
                                <div class="col-6"><strong data-tr="lblHeapFree"></strong></div>
                                <div class="col-6 text-end">${this.heapFree/1024} Kb</div>
                            </div><hr>


                            <div class="row mb-2">
                                <div class="col-6"><strong data-tr="lblCompany"></strong></div>
                                ${_company}
                            </div><hr>
                            
                                ${ApiInfo}

                            <div class="row mb-2">
                                <div class="col-6"><strong data-tr="lblUptime"></strong> (sec)</div>
                                <div class="col-6 text-end" id="divUpTime">${this.uptime / 1000}</div>
                            </div>

                        </div>
                    </div>
                `;
            }


            onTick(tick) {
                this.uptime += 1000; // aggiungi 1 secondo in millisecondi 
                const sec = (this.uptime / 1000) | 0; // bitwise trick
                setTextContent("divUpTime", sec);
                //const sec = this.uptime/1000;
                //setTextContent("divUpTime", `${this.uptime}`);
                // ogni 10 secondi
                /*
                if (tick % 10 === 0) {
                    console.log("Time: sync check");
                }
                */
            }








}
