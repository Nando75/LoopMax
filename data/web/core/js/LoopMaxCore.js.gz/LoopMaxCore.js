import { translator, setStatus, toast, initThemeToggle, buildTabs, loader, 
        fetchAPI, updateHeader, registerInstance, startGlobalTimer, setPageBkg   } from './LoopMaxUtils.js';

import { Time } from './time.js';
import { System } from './system.js';
import { Logs } from './logs.js';
import { Geo } from './geo.js';
import { Reset } from './reset.js';
import { Web } from './web.js';
import { Wifi } from './wifi.js';
import { Services } from './services.js';
import { Modules } from './modules.js';
import { Configuration } from './config.js';
import { Login } from './login.js';

export class LoopMaxCore {
    constructor() {
        loader(true);
        this.time = null;
        this.system = null;
        this.wifi = null;
        this.services = null;
        this.modules = null;
        this.geo = null;
        this.logs = null;
        this.web = null;
        this.reset = null;
        this.config = null;
        this.login = new Login(this);
    }

  
async init() {
    let message = translator.tr("load_system");
    setStatus(message + '...');
    const baseTasks = [
        { id: 'system',  trKey: 'load_system' },
        { id: 'wifi',     trKey: 'load_wifi' },
        { id: 'modules', trKey: 'load_modules' }
    ];
    await this.loadTasksSequential(baseTasks);
    const mode = this.system.getMode();
    const isLogged = this.system.isLogged();
    const online = this.wifi.isOnline();
    if(mode != "AP" && online) setPageBkg();
    const lng = this.system.getLanguage();
    translator.setLanguage(lng);
    translator.initLanguageSelector();
    if(!isLogged) await this.loadLogin();
    if(isLogged) await this.loadPage();
    startGlobalTimer(1000);
    loader(false);
}

    refreshPage()
    {
        let message = translator.tr("load_system");
        setStatus(message + ' ✅', true);
        updateHeader();
        message = translator.tr("msgBuildUi");
        setStatus(message, true);
        
        translator.translatePage();
        startGlobalTimer(1000);
        initThemeToggle();
        setStatus(translator.tr('boot_ok') + ' 🎉', true);
        //toast(translator.tr('boot_ok'), "success");
    }

    async loadLogin()
        {
            const DevName = this.modules ? this.modules.getFirstDeviceName() : "";
            const idsCore = ["Login"];
            const labelsCore = ["lbl_Login"];
            const contentsCore = [
                this.login.getHtml(DevName)
            ];
            buildTabs(idsCore, labelsCore, contentsCore);
            this.login.initObjects();
            this.refreshPage();
        }


        async loadPage()
        {

            const protectedTasks = [
                { id: 'time',     trKey: 'load_time' },
                { id: 'logs',     trKey: 'load_logs' },
                { id: 'geo',      trKey: 'load_geo' },
                { id: 'reset',    trKey: 'load_reset' },
                { id: 'web',      trKey: 'load_web' },
                { id: 'services', trKey: 'load_services' }
            ];
            await this.loadTasksSequential(protectedTasks);
            await this.time.checkTime();
            this.config = new Configuration();
            // Tabs core
            const idsCore = ["Config", "Modules", "Services", "Logs"];
            const labelsCore = ["lbl_Conf", "lbl_Modules", "lbl_Services", "lbl_Logs"];
            const contentsCore = [
                this.config.getHtml(),
                this.modules.getHtml(),
                this.services.getHtml(),
                this.logs.getHtml()
            ];

            // Load modules
            const modulesTabs = await this.loadModules(this.modules);
            const ids = [...modulesTabs.ids, ...idsCore];
            const labels = [...modulesTabs.labels, ...labelsCore];
            const contents = [...modulesTabs.contents, ...contentsCore];

            // Build once
            buildTabs(ids, labels, contents);

            this.services.renderStateSelect();
            this.logs.renderTypeSelect();
            this.logs.renderTable();
            this.config.initObjects();

            // INIT MODULES TABS
            await this.initModuleObjects(this.modules);
            this.showBtLogout();
            this.refreshPage();
        }

        showBtLogout()
            {
            const btLogOut = document.getElementById("btLogOut");
            if(btLogOut)
            {
                btLogOut.classList.remove("d-none");
                btLogOut.onclick = async () => {
                    loader(true);
                    try {
                        await this.login.logout();
                        this.loadLogin();
                    } catch (err) {
                        console.error(err);
                    }
                    loader(false);
                };
            }
        }



        async loadTasksSequential(tasks) {

             const results = await Promise.all(
                tasks.map(task =>
                    fetchAPI('json/' + task.id)
                        .then(data => ({ task, data, error: null }))
                        .catch(error => ({ task, data: null, error }))
                )
            );
            for (const result of results) {
                const { task, data, error } = result;
                if (error) {
                    console.error(`Error ${task.id}:`, error);
                    setStatus(translator.tr(task.trKey) + ' ❌', false);
                    continue;
                }
                setStatus(translator.tr(task.trKey) + ' ✔️', true);
                //console.log(data);
                switch (task.id) {
                    case 'system':
                        this.system = new System(data.system);
                        registerInstance("system", this.system);
                        break;
                    case 'time':
                        this.time = new Time(data.time);
                        registerInstance("time", this.time);
                        break;
                    case 'logs':
                        this.logs = new Logs(data.logs);
                        registerInstance("logs", this.logs);
                        break;
                    case 'geo':
                        this.geo = new Geo(data.geo);
                        registerInstance("geo", this.geo);
                        break;
                    case 'reset':
                        this.reset = new Reset(data.reset);
                        registerInstance("reset", this.reset);
                        break;
                    case 'wifi':
                        this.wifi = new Wifi(data.wifi);
                        registerInstance("wifi", this.wifi);
                        break;
                    case 'web':
                        this.web = new Web(data.web);
                        registerInstance("web", this.web);
                        break;
                    case 'services':
                        this.services = new Services(data.services);
                        registerInstance("services", this.services);
                        break;
                    case 'modules':
                        this.modules = new Modules(data.modules);
                        registerInstance("modules", this.modules);
                        break;
                }

            }
          
            
        }


        async loadModules(modulesObj) {
            const promises = [];
            for (const key in modulesObj.modules) {
                const mod = modulesObj.modules[key];
                if (!mod || !mod.JsUIClass) continue;
                const moduleName = mod.Name.toLowerCase();
                //const jsPath = `/modules/${moduleName}/${mod.JsUIClass.toLowerCase()}`;
                const jsPath = `/modules/${mod.JsUIClass.toLowerCase()}`;

                promises.push((async () => {
                    try {
                        const module = await import(jsPath);
                        if (!module?.default) return null;
                        const instance = new module.default(mod);
                        // FILTRO: solo se l'istanza è valida
                        if (!instance) return null;
                        const html = instance.getHtml?.() ?? "";
                        return { moduleName, label: mod.Name, html, instance };
                    } catch (e) {
                        let msg = translator.tr("errModuleNotFound");
                        toast(msg.replace("@@modulePath@@",jsPath), "danger");
                        console.error(msg.replace("@@modulePath@@",jsPath), e);
                        return { moduleName, error: e };
                    }
                })());
            }
            const results = await Promise.allSettled(promises);
            const ids = [];
            const labels = [];
            const contents = [];
            for (const r of results) {
                if (r.status !== "fulfilled" || !r.value) continue;
                if (r.value.error) continue; // <-- salto moduli falliti
                ids.push(r.value.moduleName);
                labels.push(r.value.label);
                contents.push(r.value.html);
                // SALVO l'istanza solo se valida
                if (r.value.instance) {
                    modulesObj[r.value.moduleName] = r.value.instance;
                }
            }
            return { ids, labels, contents };
        }



/*
            async loadModules(modulesObj) {
                const promises = [];
                for (const key in modulesObj.modules) {
                    const mod = modulesObj.modules[key];
                    if (!mod || !Array.isArray(mod.JsFiles) || !mod.JsFiles.length) continue;
                    const moduleName = mod.Name.toLowerCase();
                    const jsPaths = mod.JsFiles.map(f => `/modules/${f.toLowerCase()}`);
                    promises.push((async () => {
                        try {
                            const imports = await Promise.all(jsPaths.map(p => import(p)));
                            const module = imports.find(m => m?.default);
                            if (!module) return null;
                            const instance = new module.default(mod);
                            if (!instance) return null;
                            const html = instance.getHtml?.() ?? "";
                            return { moduleName, label: mod.Name, html, instance };
                        } catch (e) {
                            let msg = translator.tr("errModuleNotFound");
                            toast(msg.replace("@@modulePath@@", jsPaths.join(",")), "danger");
                            console.error(msg.replace("@@modulePath@@", jsPaths.join(",")), e);
                            return { moduleName, error: e };
                        }
                    })());
                }
                const results = await Promise.allSettled(promises);
                const ids = [];
                const labels = [];
                const contents = [];
                for (const r of results) {
                    if (r.status !== "fulfilled" || !r.value) continue;
                    if (r.value.error) continue;
                    ids.push(r.value.moduleName);
                    labels.push(r.value.label);
                    contents.push(r.value.html);
                    if (r.value.instance) {
                        modulesObj[r.value.moduleName] = r.value.instance;
                    }
                }
                return { ids, labels, contents };
            }
*/

        //ASYNCRONA:
        async initModuleObjects(modulesObj) {
            const tasks = [];
            for (const key in modulesObj.modules) {
                const mod = modulesObj.modules[key];
                if (!mod.JsUIClass || !modulesObj[key]) continue;
                const instance = modulesObj[key];
                if (!instance || typeof instance.initObjects !== "function") continue;
                tasks.push((async () => {
                    try {
                        await instance.initObjects();
                    } catch (e) {
                        console.error(`initObjects fallito per modulo ${key}:`, e);
                    }
                })());
            }
            await Promise.allSettled(tasks);
        }


}



// --- ISTANZIAMENTO AUTOMATICO ---
document.addEventListener('DOMContentLoaded', () => {
    window.Core = new LoopMaxCore();
    window.Core.init();
});
