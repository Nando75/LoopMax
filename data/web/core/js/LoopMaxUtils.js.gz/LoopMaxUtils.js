import { Translator } from './translator.js';
const _apiCloud = "https://smartilab.it/";
const _apiWebApp = "https://smartilab.it/webapp/";

let _apiBase = null;

export function detectApiBase() {
    if (_apiBase !== null) return _apiBase; // già calcolata

    const host = window.location.hostname;
    const isLocal =
        host === "localhost" ||
        host.endsWith(".local") ||
        /^(192\.168\.|10\.|172\.)/.test(host);
    _apiBase = isLocal ? "" : _apiCloud;
    return _apiBase;
}

export function CloudUrl() {
  return _apiCloud;
}

export function WebAppUrl() {
  return _apiWebApp;
}


export function getToken() {
  return localStorage.getItem("token");
}

export function setToken(token) {
  localStorage.setItem("token", token);
}

export function clearToken() {
  localStorage.removeItem("token");
}

function authHeaders(extraHeaders = {}) {
  const token = getToken();
  const headers = { ...extraHeaders };

  if (token) {
    headers["Authorization"] = "Bearer " + token;
  }

  return headers;
}


/*
export async function fetchAPIstatus(endpoint) {
    const apiBase = detectApiBase(); // già cache-ato
    const response = await fetch(`${apiBase}/api/${endpoint}`);
    if (!response.ok) throw new Error(`Status: ${response.status}`);
    return "ok";
}
*/
export async function fetchAPIstatus(endpoint) {
  const apiBase = detectApiBase();
  const response = await fetch(`${apiBase}/api/${endpoint}`, {
    headers: authHeaders()
  });

  if (!response.ok) throw new Error(`Status: ${response.status}`);
  return "ok";
}


/*
export async function fetchAPI(endpoint) {
    const apiBase = detectApiBase(); // ora è cached
    //console.log("POST URL:", `${apiBase}/api/${endpoint}`);
    const response = await fetch(`${apiBase}/api/${endpoint}`);
    if (!response.ok) throw new Error(`Status: ${response.status}`);
    return await response.json();
}
*/
export async function fetchAPI(endpoint) {
  const apiBase = detectApiBase();
  const response = await fetch(`${apiBase}/api/${endpoint}`, {
    headers: authHeaders()
  });

  if (!response.ok) throw new Error(`Status: ${response.status}`);
  return await response.json();
}


/*
export async function sendAPI(endpoint, options = {}) {
    const apiBase = detectApiBase();

    const response = await fetch(`${apiBase}/api/${endpoint}`, {
        method: options.method || "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: options.body || null
    });

    if (!response.ok) throw new Error(`Status: ${response.status}`);

    if (options.return === "text") return await response.text();
    if (options.return === "json") return await response.json();

    return response;
}
*/
export async function sendAPI(endpoint, options = {}) {
  const apiBase = detectApiBase();

  const response = await fetch(`${apiBase}/api/${endpoint}`, {
    method: options.method || "POST",
    headers: authHeaders({
      "Content-Type": "application/x-www-form-urlencoded"
    }),
    body: options.body || null
  });

  if (!response.ok) throw new Error(`Status: ${response.status}`);

  if (options.return === "text") return await response.text();
  if (options.return === "json") return await response.json();

  return response;
}





     export function  loader(show) {
        const loader = document.getElementById('loadingOverlay');
        if (loader) loader.classList.toggle('d-none', !show);

        // Se mostri lo spinner, pulisci la lista dei messaggi
        if (show) {
            const status = document.getElementById('loadingStatus');
            if (status) status.innerHTML = '';
        }
    }

    export function  setStatus(message, success = null) {
        const status = document.getElementById('loadingStatus');
        if (!status) return;

        status.textContent = message;

        if (success === true) status.style.color = 'lightgreen';
        else if (success === false) status.style.color = 'salmon';
        else status.style.color = 'white';
    }



    // --- TOASTS (Notifiche) ---
    export function  toast(message, type = 'info') {
        const container = document.getElementById('toastContainer');
        const id = 'toast_' + Date.now();
        const html = `
            <div id="${id}" class="toast align-items-center text-white bg-${type} border-0" role="alert">
                <div class="d-flex">
                    <div class="toast-body">${message}</div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            </div>`;
        container.insertAdjacentHTML('beforeend', html);
        const el = document.getElementById(id);
        const toast = new bootstrap.Toast(el, { delay: 5000 });
        toast.show();
        el.addEventListener('hidden.bs.toast', () => el.remove());
    }

        // --- BUILDER DI COMPONENTI ---
    export function  createElement(tag, classes = [], text = "") {
        const el = document.createElement(tag);
        if (classes.length) el.classList.add(...classes);
        if (text) el.innerText = text;
        return el;
    }


export function updateHeader() {
    let name = "LoopMax";
    let company = "SmartiLab.it";

    const modsInstance = modules(); // getter export, o registry.modules

    if (modsInstance && typeof modsInstance.list === "function") {
        const names = modsInstance.list(); // es: ["zappy"]
        if (names.length > 0) {
            const first = modsInstance.get(names[0]); // oggetto del modulo
            if (first) {
                name = first.Name || name;
                company = "by " + first.Company || company;
            }
        }
    }

    const devEl  = document.getElementById('headerTitle');
    const compEl = document.getElementById('headerSubTitle');

    if (devEl)  devEl.innerText  = name || "LoopMax";
    if (compEl) compEl.innerText = company || "SmartiLab.it";

    const devSys = system();
    if(!devSys)  return;
    if(devSys.debug) { 
        const bd = document.getElementById("bdDebug");
        bd.textContent = "DEBUG";
        bd.classList.remove("d-none");
        //toast("Debug Mode", "danger");
    }

    const bdMode = document.getElementById('bdOperatingMode');
    if(bdMode)
    {
        let text = devSys.getMode();
        if(text != 'AP') bdMode.classList.remove('bg-secondary');
        if(text == 'LAN') bdMode.classList.add('bg-primary');
        bdMode.textContent = text;
    }

    document.getElementById("footerDevInfo").textContent = devSys.summary();
    
}





export function updateFooter()
{
    const devSys = system();
    if(!devSys)  return;
    const mode = devSys.mode || "AP";
    const fTransl = registry.translator.tr("footerText");
    let fText = fTransl + " - <b>" +  devSys.Company + "</b>"; //(AP)
    if(mode === 'LAN' || mode === 'CLOUD') { 
        fText = fTransl + " - <a href='"+ devSys.url +"' target='_blank'>" +  devSys.Company + "</a>";
    }
    const footerSpan = document.getElementById("pageFooter").querySelector("span");
    if(footerSpan) footerSpan.innerHTML = fText;
}

export function setPageBkg() {
    const url = _apiCloud + "wp-content/uploads/2026/01/LoopMaxOS.webp";
    const opacity = 0.04;
    const size = 'contain';
    const position = 'center center';
    const repeat = 'no-repeat';
    const fixed = true;
    let bg = document.getElementById('bgOverlay');
    if (!bg) {
        bg = document.createElement('div');
        bg.id = 'bgOverlay';
        document.body.appendChild(bg);
    }
    Object.assign(bg.style, {
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        zIndex: '-1',
        backgroundImage: `url('${url}')`,
        backgroundRepeat: repeat,
        backgroundPosition: position,
        backgroundSize: size,
        backgroundAttachment: fixed ? 'fixed' : 'scroll',
        opacity: opacity
    });
}


    export function  buildTabs(ids, labels, contents) {
            const tabList = document.getElementById("configTabs");
            const tabContent = document.getElementById("configTabsContent");

            // Pulisce i tab dinamici precedenti
            tabList.querySelectorAll("li.dynamic-tab").forEach(el => el.remove());
            tabContent.innerHTML = "";

            for (let i = 0; i < ids.length; i++) {
                const id = ids[i];
                const label = labels[i];
                const content = contents[i];
                const isActive = i === 0 ? "active" : "";

                // Tab header
                const li = document.createElement("li");
                li.className = "nav-item dynamic-tab";
                li.role = "presentation";

                const btn = document.createElement("button");
                btn.className = `nav-link secondFont ${isActive}`;
                btn.id = `tabLnk-${id}`;
                btn.dataset.bsToggle = "tab";
                btn.dataset.bsTarget = `#tab-${id}`;
                btn.type = "button";
                btn.role = "tab";
                btn.innerText = label;
                btn.setAttribute("data-tr", label);

                li.appendChild(btn);
                tabList.insertBefore(li, tabList.lastElementChild); // prima del blocco tema/lingua

                // Tab content
                const div = document.createElement("div");
                div.className = `tab-pane fade ${isActive ? "show active" : ""}`;
                div.id = `tab-${id}`;
                div.role = "tabpanel";
                div.innerHTML = content;

                tabContent.appendChild(div);
            }
    }


    /*
    // ======================== THEMA ==========================
    export function  initThemeToggle() {


        const btn = document.getElementById("themeToggle");
        const body = document.body;

        console.log("init toggle", btn);

        let theme = localStorage.getItem("theme") || "light";
        body.setAttribute("data-bs-theme", theme);
        btn.innerHTML = theme === "dark" ? "☀️" : "🌙";

        btn.addEventListener("click", () => {
            let next = body.getAttribute("data-bs-theme") === "light" ? "dark" : "light";
            body.setAttribute("data-bs-theme", next);
            localStorage.setItem("theme", next);
            btn.innerHTML = next === "dark" ? "☀️" : "🌙";
        });
    }
        */

    export function initThemeToggle() {
    const btn = document.getElementById("themeToggle");
    if (!btn) return;

    const body = document.body;

    let theme = localStorage.getItem("theme") || "light";
    body.setAttribute("data-bs-theme", theme);
    btn.innerHTML = theme === "dark" ? "☀️" : "🌙";

    btn.onclick = () => {   // ⭐ SOVRASCRIVE, NON ACCUMULA
        let next = body.getAttribute("data-bs-theme") === "light" ? "dark" : "light";
        body.setAttribute("data-bs-theme", next);
        localStorage.setItem("theme", next);
        btn.innerHTML = next === "dark" ? "☀️" : "🌙";
    };
}


    

    export function setTextContent(id, value) {
        const obj = document.getElementById(id);
        //console.log("setTextContent:", id, "found:", !!obj);
        if (obj) obj.textContent = value ?? "-";
    }






//export const translator = new Translator();

// Registry globale del modulo
const registry = {
    translator: new Translator(),
    system: null,
    time: null,
    logs: null,
    geo: null,
    reset: null,
    wifi: null,
    web: null,
    services: null,
    modules: null
};

// Setter per il Core
export function registerInstance(name, instance) {
    if (!(name in registry)) {
        console.error("Registry: chiave sconosciuta:", name);
        return;
    }
    registry[name] = instance;
}

// Getter universale
export function getInstance(name) {
    return registry[name];
}








// ========================= GLOBAL TIMER =========================

const timerRegistry = new Map();
let timerInterval = null;
let tickCount = 0;

/**
 * Avvia il timer globale
 * @param {number} ms intervallo in millisecondi
 */
export function startGlobalTimer(ms = 1000) {
    if (timerInterval) return; // già avviato

    timerInterval = setInterval(() => {
        tickCount++;

        // Notifica tutti i listener registrati
        for (const [id, handler] of timerRegistry.entries()) {
            try {
                handler(tickCount);
            } catch (e) {
                console.error("Errore nel timer handler:", id, e);
            }
        }

    }, ms);
}

/**
 * Registra un listener
 * @param {string} id nome univoco del modulo
 * @param {function} callback funzione(tick)
 */
export function registerTimer(id, callback) {
    timerRegistry.set(id, callback);
}

/**
 * Deregistra un listener
 */
export function unregisterTimer(id) {
    timerRegistry.delete(id);
}



export function escapeHtml(str) {
    return str.replace(/[&<>"']/g, m => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
    })[m]);
}

export const translator = registry.translator;
export const system   = () => registry.system;
export const time     = () => registry.time;
export const logs     = () => registry.logs;
export const geo      = () => registry.geo;
export const reset    = () => registry.reset;
export const wifi     = () => registry.wifi;
export const web      = () => registry.web;
export const services = () => registry.services;
export const modules  = () => registry.modules;
