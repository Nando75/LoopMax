import { translator, toast, loader, escapeHtml, fetchAPI } from './LoopMaxUtils.js';

export class Logs {
    constructor(json = {}) {
        this.list = [];
        this.types = [];
        this.typeMap = {};
        this.sortField = "millis";
        this.sortDir = "asc";
        this.filterType = "";
        this.lastSeenMillis = null;
        this.seenMap = {};
        this.refreshTable(json);
        this.refreshTypes(json);

    }




    getIconFor(type) {
        return this.typeMap[type] || "•";
    }

    getFilteredSortedLogs() {
        let logs = [...this.list];
        if (this.filterType) logs = logs.filter(l => l.type === this.filterType);

        logs.sort((a, b) => {
            let v1 = a[this.sortField];
            let v2 = b[this.sortField];
            if (typeof v1 === "string") v1 = v1.toLowerCase();
            if (typeof v2 === "string") v2 = v2.toLowerCase();
            if (v1 < v2) return this.sortDir === "asc" ? -1 : 1;
            if (v1 > v2) return this.sortDir === "asc" ? 1 : -1;
            return 0;
        });

        return logs;
    }

    setSort(field) {
        if (this.sortField === field) {
            this.sortDir = this.sortDir === "asc" ? "desc" : "asc";
        } else {
            this.sortField = field;
            this.sortDir = "asc";
        }
        this.updateSortIcons();
        this.renderTable();
    }

    setFilter(type) {
        this.filterType = type;
        this.renderTable();
    }

    updateSortIcons() {
        ["millis", "src", "type"].forEach(f => {
            const el = document.getElementById("sort-" + f);
            if (!el) return;
            el.textContent = f === this.sortField ? (this.sortDir === "asc" ? " ▲" : " ▼") : "";
        });
    }

    refreshTable(json = {}) {
        this.list = Array.isArray(json.list) ? json.list : [];
        this.sortField = "millis";
        this.sortDir = "asc";
        this.filterType = "";
        this.lastSeenMillis = null;
        this.seenMap = {};
    }


     refreshTypes(json = {}) {
        this.types = Array.isArray(json.types) ? json.types : [];
        this.typeMap = {};
        for (const t of this.types) {
            if (t.name) this.typeMap[t.name] = t.icon || "";
        }
    }

    renderTable() {
        
         const bd = document.getElementById("bdLogsCount");
         if (bd) bd.textContent = this.list.length || 0;

        const body = document.getElementById("syslog-body");
        if (!body) return;
        const logs = this.getFilteredSortedLogs();
        const now = Date.now();
        body.innerHTML = "";
        if (logs.length === 0) {
            body.innerHTML = `<tr><td colspan="4" class="text-center text-muted py-3">No logs</td></tr>`;
            this.renderTimeline();
            return;
        }

        const table = document.querySelector("#logsAccordion table"); 
        if (table) {
            const headers = table.querySelectorAll("th[data-key]"); 
            headers.forEach(th => {
                const key = th.getAttribute("data-key");
                // Event handler
                th.onclick = () => this.setSort(key);
                // Visuale ordinamento
                const isActive = key === this.sortKey;
                const arrow = isActive ? (this.sortAsc ? "↑" : "↓") : "";
                th.innerHTML = `${translator.tr(th.dataset.tr)} ${arrow}`;
                th.style.cursor = "pointer";
            });
        }

        logs.forEach(log => {
            const tr = document.createElement("tr");
            const key = `${log.millis}-${log.src}-${log.msg}`;
            if (this.lastSeenMillis !== null && log.millis > this.lastSeenMillis && !this.seenMap[key]) {
                this.seenMap[key] = now;
            }
            const isNew = this.seenMap[key] && (now - this.seenMap[key] < NEW_BADGE_TTL);

            tr.innerHTML = `
                <td class="text-muted small">${log.millis}</td>
                <td class="secondFont">${log.sIcon || ""} ${log.src.toUpperCase() || ""}</td>
                <td><span class="badge ${this.getLogTypeClass(log.type)}">${log.icon || ""} ${log.type}</span></td>
                <td class="text-break">
                    ${log.msg || ""}
                    ${isNew ? `<span class="badge rounded-pill bg-success-subtle text-success small ms-2">new</span>` : ""}
                    ${this.renderPayload(log.pld)}
                </td>
                `;

            body.appendChild(tr);
        });

        const maxMillis = Math.max(0, ...logs.map(l => l.millis || 0));
        this.lastSeenMillis = this.lastSeenMillis === null ? maxMillis : Math.max(this.lastSeenMillis, maxMillis);

        this.renderTimeline();
        this.renderEventsTimeline();
    }

renderTimeline() {
    this.buildTimeline(
        "boot-timeline",
        l => l.millis >= 0 && l.millis <= 1000,
        "bg-primary"
    );
}

renderEventsTimeline() {
    this.buildTimeline(
        "events-timeline",
        l => l.millis > 1000,
        "bg-success"
    );
}

buildTimeline(containerId, filterFn, barClass) {
    const container = document.getElementById(containerId);
    if (!container) return;
    container.innerHTML = "";
    const logs = this.list
        .filter(l => typeof l.millis === "number")
        .filter(filterFn)
        .sort((a, b) => a.millis - b.millis);
       //console.log(`TIMELINE ${containerId}`,logs.map(l => l.millis));
    if (logs.length === 0) {
        container.innerHTML = `<span>No logs</span>`;
        return;
    }
    const maxMillis = Math.max(...logs.map(l => l.millis || 0)) || 1;
    logs.forEach(log => {
        const percent = (log.millis / maxMillis) * 100;
        const row = document.createElement("div");
        row.innerHTML = `
            <div class="small text-muted mb-1">
                ${log.icon || ""} ${log.src} – ${log.msg}
                <span class="float-end">${log.millis} ms</span>
            </div>
            <div class="progress" style="height: 6px;">
                <div class="progress-bar ${barClass}" role="progressbar" style="width: ${percent}%"></div>
            </div>
        `;
        container.appendChild(row);
    });
}


renderTypeSelect() {
    const select = document.getElementById("logTypeSelect");
    if (!select) return;

    const clone = select.cloneNode(true);
    select.parentNode.replaceChild(clone, select);

    clone.innerHTML = "";

    // --- COUNT DEI TIPI ---
    const counts = {};
    this.list.forEach(log => {
        const type = log.type || "";
        counts[type] = (counts[type] || 0) + 1;
    });

    // ALL
    const optAll = document.createElement("option");
    optAll.value = "";
    optAll.textContent = `All (${this.list.length || 0})`;
    clone.appendChild(optAll);

    // TIPI
    this.types.forEach(t => {
        const opt = document.createElement("option");
        opt.value = t.name;

        const count = counts[t.name] || 0;
        opt.textContent = `${t.icon} ${this.capitalize(t.name)} (${count})`;

        clone.appendChild(opt);
    });

    clone.addEventListener("change", () => this.setFilter(clone.value));

    const btnRefresh = document.getElementById("btnLogRefresh");
    if (btnRefresh) btnRefresh.onclick = () => this.refresh();

    const btnRefresh2 = document.getElementById("btnLogRefresh2");
    if (btnRefresh2) btnRefresh2.onclick = () => this.refresh();

    const btnRefresh3 = document.getElementById("btnLogRefresh3");
    if (btnRefresh3) btnRefresh3.onclick = () => this.refresh();


    const btnReset = document.getElementById("btnLogReset");
    if (btnReset) btnReset.onclick = () => this.reset();
}



getHtml() {
    return `
<div class="accordion" id="logsAccordion">

<div class="accordion-item">
    <h2 class="accordion-header" id="headingTimeline">
      <button class="accordion-button collapsed secondFont" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTimeline" aria-expanded="false" aria-controls="collapseTimeline" data-tr="lblBootTimeLine">
      </button>
    </h2>
    <div id="collapseTimeline" class="accordion-collapse collapse" aria-labelledby="headingTimeline" data-bs-parent="#logsAccordion">
      <div class="accordion-body">
            <div class="d-flex align-items-center gap-2 mb-3 flex-wrap">
                <button id="btnLogRefresh2" class="btn btn-sm btn-outline-primary secondFont" type="button" data-tr="lblRefresh"></button>
            </div>
        <div id="boot-timeline" class="mt-2"></div>
      </div>
    </div>
  </div>


 <div class="accordion-item">
    <h2 class="accordion-header" id="headingTimeline">
      <button class="accordion-button collapsed secondFont" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEvTimeline" aria-expanded="false" aria-controls="collapseTimeline" data-tr="lblEvTimeLine">
      </button>
    </h2>
    <div id="collapseEvTimeline" class="accordion-collapse collapse" aria-labelledby="headingTimeline" data-bs-parent="#logsAccordion">
      <div class="accordion-body">
            <div class="d-flex align-items-center gap-2 mb-3 flex-wrap">
                <button id="btnLogRefresh3" class="btn btn-sm btn-outline-primary secondFont" type="button" data-tr="lblRefresh"></button>
            </div>
        <div id="events-timeline" class="mt-2"></div>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="headingLogs">
      <button class="accordion-button secondFont" type="button" data-bs-toggle="collapse" data-bs-target="#collapseLogs" aria-expanded="true" aria-controls="collapseLogs">
        📋 Logs 
        <small id="bdLogsCount" class="ms-2 badge bg-primary"></small>
      </button>
    </h2>
    <div id="collapseLogs" class="accordion-collapse collapse" aria-labelledby="headingLogs" data-bs-parent="#logsAccordion">
      <div class="accordion-body">
        <div class="d-flex align-items-center gap-2 mb-3 flex-wrap">
            <select id="logTypeSelect" class="form-select form-select-sm w-auto secondFont"></select>
            <button id="btnLogRefresh" class="btn btn-sm btn-outline-primary secondFont" type="button" data-tr="lblRefresh"></button>
            <button id="btnLogReset" class="btn btn-sm btn-outline-danger secondFont" type="button" data-tr="lblDelete"></button>
        </div>

        <table class="table table-sm table-hover">
          <thead>
            <tr>
              <th id="sort-millis" data-key="millis" style="cursor:pointer" class="secondFont" data-tr="lblTime"></th>
              <th id="sort-src" data-key="src" style="cursor:pointer" class="secondFont" data-tr="lblSource"></th>
              <th id="sort-type" data-key="type" style="cursor:pointer" class="secondFont" data-tr="lblType"></th>

              <th data-tr="lblMessage" class="secondFont"></th>
            </tr>
          </thead>
          <tbody id="syslog-body"></tbody>
        </table>
      </div>
    </div>
  </div>

</div>
    `;
}


    async refresh() {
        loader(true);
        try {
            const json = await fetchAPI('json/logs');

            //console.log(json);

            this.refreshTable(json.logs);
            this.renderTypeSelect(); 
            this.renderTable();

        } catch (err) {
            console.error(err.message);
            toast("Errore comunicazione con ESP", "danger");
        } finally
        { loader(false); }
    }

    async reset() {
        if (!confirm(translator.tr("msgDeleteLogs"))) return;
        try {
            const json = await fetchAPI('logs/reset');
            
            //console.log(json);

            this.refreshTable(json.logs);
            this.renderTypeSelect(); 
            this.renderTable();

        } catch (err) {
            console.error(err.message);
            toast("Errore comunicazione con ESP", "danger");
        }

    }



    capitalize(str) {
        return typeof str === "string" && str.length > 0
            ? str.charAt(0).toUpperCase() + str.slice(1)
            : str;
    }

    getLogTypeClass(type) {
    const map = {
        info: "text-bg-primary",
        warning: "text-bg-warning",
        error: "text-bg-danger",
        debug: "text-bg-secondary",
        toggle: "text-bg-success",
        local: "text-bg-info",
        cloud: "text-bg-light"
    };
    return map[type] || "bg-secondary";
}



        renderPayload(pld) {
            if (!pld || typeof pld !== "string" || pld.trim() === "{}") return "";

            let parsed;
            try {
                parsed = JSON.parse(pld);
            } catch (e) {
                return `<details class="mt-1"><summary class="text-danger">Payload (malformato)</summary><pre class="text-danger small">${escapeHtml(pld)}</pre></details>`;
            }
            const pretty = JSON.stringify(parsed, null, 2);
            return `
                <details class="mt-1" style="background-color: var(--bs-tertiary-bg); border-radius: .25rem; padding: .5rem;">
                    <summary class="text-muted small">Payload</summary>
                    <pre class="small border rounded p-2 mt-1" style="background-color: var(--bs-body-bg); color: var(--bs-body-color);">${escapeHtml(pretty)}</pre>
                </details>`;
        }


}
