export class Reset {
    constructor(json) {
        this.pinMode = json.pinMode || "";
        this.pinNumber = json.pinNumber || 0;
    }






    renderCard() {
    return `
        <div class="card mt-3 shadow-sm">
            <div class="card-header fw-bold">
                Reset Info
            </div>

            <div class="card-body p-3">

                <div class="row mb-2">
                    <div class="col-6"><strong>Pin Mode:</strong></div>
                    <div class="col-6 text-end">${this.pinMode || "-"}</div>
                </div>

                <div class="row">
                    <div class="col-6"><strong>Pin Number:</strong></div>
                    <div class="col-6 text-end">${this.pinNumber}</div>
                </div>

            </div>
        </div>
    `;
}






    
}
