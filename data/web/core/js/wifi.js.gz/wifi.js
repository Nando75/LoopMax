import { translator, toast, fetchAPI, sendAPI } from './LoopMaxUtils.js';

export class Wifi {
    constructor(json) {
        this.dns = json.dns || false;
        this.mdns = json.mdns || false;
        this.apSsid = json.apSsid || "";
        this.apPsw = json.apPsw || "";
        this.ip = json.ip || "";
        this.isConnected = json.isConnected || false;
        this.localWifi = Array.isArray(json.localWifi) ? json.localWifi : [];
        this.mode = json.mode || "";
        this.wfPsw = json.wfPsw || "";
        this.wfSsid = json.wfSsid || "";
        this.wfRssi = json.wfRssi || 0;

        this.publicIp = json.publicIp || "";
        this.isp = json.isp || "";
        this.internet = json.internet || false;
        
        this.scanCooldown = false;
        this.scanInProgress = false;
        this.fetchInProgress = false;

        this.testInProgress = false;

    }

    updateData(json)
    {
        this.dns = json.dns || false;
        this.mdns = json.mdns || false;
        this.apPsw = json.apPsw || "";
        this.ip = json.ip || "";
        this.isConnected = json.isConnected || false;
        this.localWifi = Array.isArray(json.localWifi) ? json.localWifi : [];
        this.mode = json.mode || "";
        this.wfPsw = json.wfPsw || "";
        this.wfSsid = json.wfSsid || "";
    }

    // --- Metodi utili ---
    Ip() {
        return this.ip;
    }

    isOnline() {
        return this.internet;
    }


    // --- Metodi utili ---
    isAPMode() {
        return this.mode.includes("AP");
    }

    isSTAconnected() {
        return this.isConnected && this.mode.includes("STA");
    }

    hasDNS() {
        return this.dns;
    }

    hasMDNS() {
        return this.mdns;
    }

    localWifiCount() {
        return this.localWifi.length;
    }

    summary() {
        return `Mode: ${this.mode} | IP: ${this.ip} | DNS: ${this.dns} | MDNS: ${this.mdns} | Connected: ${this.isConnected}`;
    }



    renderCard() {
    const modeBadge = this.isAPMode()
        ? `<span class="badge bg-info" data-tr="lblApMode">AP Mode</span>`
        : this.isSTAconnected()
            ? `<span class="badge bg-success" data-tr="lblConnected">Connected</span>`
            : `<span class="badge bg-secondary" data-tr="lblNotConnected">Disconnected</span>`;

    const dnsBadge = this.hasDNS()
        ? `<span class="badge bg-success">DNS</span>`
        : `<span class="badge bg-secondary">DNS Off</span>`;

    const mdnsBadge = this.hasMDNS()
        ? `<span class="badge bg-success">mDNS</span>`
        : `<span class="badge bg-secondary">mDNS Off</span>`;
    
    const internetBadge = this.isOnline()
        ? `<span class="badge bg-success">ONLINE</span>`
        : `<span class="badge bg-secondary">OFFLINE</span>`;

    let localWifiHtml = ``;

    let  publicInfo = "";
    if(this.internet)
    {
        publicInfo = ` <div class="row mb-3">
                            <div class="col-6"><strong data-tr="lblPublicIp">${ translator.tr("lblPublicIp") }</strong></div>
                            <div class="col-6 text-end">${ this.publicIp }</div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-6"><strong>ISP</strong></div>
                            <div class="col-6 text-end">${ this.isp }</div>
                        </div>`;
    }
    else
    {
        localWifiHtml = `<hr><div class="mb-2 fw-bold" data-tr="lblLocalNet"></div><div id="divLocalsCard">${this.buildLocalsCard()}</div>`;
    }

    return `
        <div class="card mt-3 shadow-sm">
            <div class="card-header fw-bold d-flex justify-content-between align-items-center">
                WiFi Info
                <span>${modeBadge}</span>
            </div>

            <div class="card-body p-3">

                <div class="row mb-2">
                    <div class="col-6"><strong data-tr="lblMode"></strong></div>
                    <div class="col-6 text-end">${this.mode}</div>
                </div>

                <div class="row mb-2">
                    <div class="col-6"><strong data-tr="lblLocalIp">${ translator.tr("lblLocalIp") }</strong></div>
                    <div class="col-6 text-end">${this.ip || "-"}</div>
                </div>

                <div class="row mb-2">
                    <div class="col-6"><strong>SSID</strong></div>
                    <div class="col-6 text-end">${this.wfSsid || "-"}</div>
                </div>

                <div class="row mb-2">
                    <div class="col-6"><strong>RSSI</strong></div>
                    <div class="col-6 text-end">${this.wfRssi || "0"}</div>
                </div>

                <div class="row mb-3">
                    <div class="col-6"><strong>Access Point Ssid</strong></div>
                    <div class="col-6 text-end">${ this.apSsid }</div>
                </div>
               
                ${publicInfo}

                <div class="mb-3">
                    <strong data-tr="lbl_Services"></strong><br>
                    ${dnsBadge} ${mdnsBadge} ${internetBadge}
                </div>
                
                ${localWifiHtml}

            </div>
        </div>
    `;
}


    buildLocalsCard()
    {
        const localWifiHtml = this.localWifi.length
        ? `
            <ul class="list-group list-group-sm mb-2">
                ${this.localWifi.map(w =>
                    `<li class="list-group-item py-1 px-2 d-flex justify-content-between">
                        <span>${w.ssid}</span>
                        <span class="text-muted small">${w.rssi} dBm</span>
                    </li>`
                ).join("")}
            </ul>`
        : `<div class="text-muted small">${translator.tr("msgNoWifiNet")}</div>`;
        return localWifiHtml;
    }



async updateScanResults() {
    if (this.fetchInProgress) return;
    this.fetchInProgress = true;
    try {
        const data = await fetchAPI('wifi/results');
        if (data?.status === "Scanning") return;
        if (data?.wifi) {
            this.updateData(data.wifi);
            const divLocalsCard = document.getElementById("divLocalsCard");
            if (divLocalsCard) {
                divLocalsCard.innerHTML = this.buildLocalsCard();
            }
           this.scanInProgress = false;
        }
    } catch (err) {
        console.error(err);
    } finally {
        this.fetchInProgress = false;
    }
}

async scanLocalAndWait() {
     if (this.scanCooldown || this.scanInProgress)
    {
        toast("Attendi qualche secondo prima di rifare lo scan", "warning");
        return;
    } 

    this.scanCooldown = true;
    setTimeout(() => this.scanCooldown = false, 10000);

    this.scanInProgress = true;
    await fetchAPI('wifi/scan');
    //chiamata asincrona, torna subito scanning ...
    //ogni tot tempo chiama wifi/results che risponde scanning fino a che non termina e torna il json
    const self = this; // <-- salva il riferimento alla classe
    return new Promise((resolve, reject) => {
        const pollResults = async () => {
            try {
                const data = await fetchAPI('wifi/results');
                if (data?.status === "Scanning") {
                    setTimeout(pollResults, 1000);
                    return;
                }
                if (data?.wifi) {
                    self.updateData(data.wifi);       // usa self
                     const divLocalsCard = document.getElementById("divLocalsCard");
                    if (divLocalsCard) {
                        divLocalsCard.innerHTML = self.buildLocalsCard();
                    }
                    self.scanInProgress = false;
                    resolve(data.wifi);
                }
            } catch (err) {
                reject(err);
            }
        };
        pollResults();
    });
}



    async testConnAndWait(ssid, psw) {
            if (this.testInProgress) {
                
                toast(translator.tr("msgTestRunning"), "warning");
                return;
            }
            this.testInProgress = true;
            const form = new URLSearchParams();
            form.append("ssid", ssid);
            form.append("psw", psw);
            try {
                await sendAPI("wifi/test", {
                    method: "POST",
                    body: form.toString(),
                    return: "text"
                });
                
            } catch (err) {
                console.error(err);
            }
            const self = this;
            return new Promise((resolve, reject) => {
                const pollTest = async () => {
                    try {
                        const data = await fetchAPI('wifi/testResult');

                        if (data?.status === "Testing") {
                            // ancora in corso → riprova tra 1 secondo
                            setTimeout(pollTest, 1000);
                            return;
                        }
                        // Test finito → Success o Failed
                        self.testInProgress = false;
                        resolve(data);

                    } catch (err) {
                        self.testInProgress = false;
                        reject(err);
                    }
                };

                pollTest();
            });
    }








}
