export class Web {
    constructor(json) {
        this.cPortal = json.cPortal || false;
        this.dns = json.dns || false;
        this.isAlive = json.isAlive || false;
        this.mdns = json.mdns || false;
        this.type = json.type || "";
        this.ui = json.ui || "";
        this.url1 = json.url1 || "";
        this.url2 = json.url2 || "";
    }




    renderCard() {
    const aliveBadge = this.isAlive
        ? `<span class="badge bg-success">Online</span>`
        : `<span class="badge bg-danger">Offline</span>`;

    const dnsBadge = this.dns
        ? `<span class="badge bg-success">DNS</span>`
        : `<span class="badge bg-secondary">DNS Off</span>`;

    const mdnsBadge = this.mdns
        ? `<span class="badge bg-success">mDNS</span>`
        : `<span class="badge bg-secondary">mDNS Off</span>`;

    const cPortalBadge = this.cPortal
        ? `<span class="badge bg-warning text-dark">Captive Portal</span>`
        : `<span class="badge bg-secondary">CP Off</span>`;

    return `
        <div class="card mt-3 shadow-sm">
            <div class="card-header fw-bold d-flex justify-content-between align-items-center">
                Web Info
                <span>${aliveBadge}</span>
            </div>

            <div class="card-body p-3">

                <div class="row mb-2">
                    <div class="col-6" data-tr="lblType"><strong></strong></div>
                    <div class="col-6 text-end">${this.type || "-"}</div>
                </div>

                <div class="row mb-2">
                    <div class="col-6"><strong>UI:</strong></div>
                    <div class="col-6 text-end">${this.ui || "-"}</div>
                </div>

                <div class="mb-3">
                    <strong data-tr="lbl_Services"></strong><br>
                    ${dnsBadge} ${mdnsBadge} ${cPortalBadge}
                </div>

                <hr>

                <div class="row mb-2">
                    <div class="col-6"><strong>URL 1:</strong></div>
                    <div class="col-6 text-end">
                        ${this.url1 ? `<a href="${this.url1}" target="_blank">${this.url1}</a>` : "-"}
                    </div>
                </div>

                <div class="row">
                    <div class="col-6"><strong>URL 2:</strong></div>
                    <div class="col-6 text-end">
                        ${this.url2 ? `<a href="${this.url2}" target="_blank">${this.url2}</a>` : "-"}
                    </div>
                </div>

            </div>
        </div>
    `;
}





    
}
