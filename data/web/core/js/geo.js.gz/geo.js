import { wifi, system  } from './LoopMaxUtils.js';

export class Geo {
    constructor(json) {
        this.accuracy = json.accuracy || 0;
        this.altitude = json.altitude || 0;
        this.hasFix = json.hasFix || false;
        this.latitude = json.latitude || 0;
        this.longitude = json.longitude || 0;
        this.continent = json.continent || "";
        this.continentCode = json.continentCode || "";
        this.country = json.country || "";
        this.countryCode = json.countryCode || "";
        this.region = json.region || "";
        this.city = json.city || "";

        this.wifi = wifi();
        this.system = system();
    }



    renderCard() {
        const mode = this.system.getMode();
        const fixBadge = this.hasFix
            ? `<span class="badge bg-success">Fix OK</span>`
            : `<span class="badge bg-danger">No Fix</span>`;

            let  publicInfo = "";

            if(mode=='LAN')
            {
                publicInfo = `<div class="row mb-2">
                                    <div class="col-6"><strong data-tr="lblContinent"></strong></div>
                                    <div class="col-6 text-end">${this.continent}</div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-6"><strong data-tr="lblContinentCode"></strong></div>
                                    <div class="col-6 text-end">${this.continentCode}</div>
                                </div>

                                <div class="row mb-2">
                                    <div class="col-6"><strong data-tr="lblCountry"></strong></div>
                                    <div class="col-6 text-end">${this.country}</div>
                                </div>

                                <div class="row mb-2">
                                    <div class="col-6"><strong data-tr="lblCountryCode"></strong></div>
                                    <div class="col-6 text-end">${this.countryCode}</div>
                                </div>

                                <div class="row mb-2">
                                    <div class="col-6"><strong data-tr="lblRegion"></strong></div>
                                    <div class="col-6 text-end">${this.region}</div>
                                </div>

                                <div class="row mb-2">
                                    <div class="col-6"><strong data-tr="lblCity"></strong></div>
                                    <div class="col-6 text-end">${this.city}</div>
                                </div>`;
                }


        return `
            <div class="card mt-3 shadow-sm">
                <div class="card-header fw-bold d-flex justify-content-between align-items-center">
                    Geo Info
                    <span>${fixBadge}</span>
                </div>

                <div class="card-body p-3">

                    <div class="row mb-2">
                        <div class="col-6"><strong data-tr="lblLat"></strong></div>
                        <div class="col-6 text-end">${this.latitude}</div>
                    </div>

                    <div class="row mb-2">
                        <div class="col-6"><strong data-tr="lblLon">:</strong></div>
                        <div class="col-6 text-end">${this.longitude}</div>
                    </div>

                    <div class="row mb-2">
                        <div class="col-6"><strong data-tr="lblAlt"></strong></div>
                        <div class="col-6 text-end">${this.altitude} m</div>
                    </div>

                    <div class="row mb-2">
                        <div class="col-6"><strong data-tr="lblAcc"></strong></div>
                        <div class="col-6 text-end">${this.accuracy} m</div>
                    </div>
                    ${publicInfo}
                </div>
            </div>`;

    }
    
    
}
