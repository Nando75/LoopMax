import { toast, loader, updateFooter } from './LoopMaxUtils.js';

export class Translator {
    constructor() {
        this.currentLng = "EN"; // Default
        this.languages = ["IT", "EN"];

        this.contents = {
            "lblInfoName":    { it: "Nome", en: "Name" },
            "lblInfoCode":    { it: "Codice", en: "Code" },
            "lblInfoIP":      { it: "Indirizzo Ip", en: "Ip Address" },
            "lblInfoFW":      { it: "Versione Firmware", en: "Firmware Version" },
            "lblInfoMode":    { it: "Modalità operativa", en: "Operating mode" },
            "lblInfoLng":     { it: "Lingua", en: "Language" },
            "lblChann":       { it: "Canali", en: "Channels" },
            "lblInfoCompany": { it: "Azienda", en: "Company" },
            "btInfoRed":      { it: "Rete", en: "Network" },
            "btInfoGen":      { it: "Dispositivo", en: "Device" },
            "tabInfoTitle":   { it: "Informazioni Dispositivo", en: "Device informations" },
            
            "msgCmdExecuted": { it: "✔️ Comando eseguito.", en: "✔️ Command executed" },
            "errCmdNotExecuted": { it: "❌ Comando non eseguito.", en: "❌ Command not executed" },
            
            "lblRestarting": { it: "✔️ Riavvio in corso ...", en: "✔️ Restarting ..." },
            "lblLoginok": { it: "✔️ Accesso riuscito,\nattendere caricamento pagina", en: "✔️ Login successful, page loading." },
            "lblLoginFailed": { it: "❌ Accesso non riuscito", en: "❌ Login failed" },
            "lbl_Login": { it: "🔐 Login utente", en: "🔐 User login" },
            "lblLocalIp": { it: "Ip locale", en: "Local Ip" },
            "lblPublicIp": { it: "Ip pubblico", en: "Public Ip" },
            "lblCapital": { it: "Capitale", en: "Capital" },
            "lblPostal": { it: "Cod. postale", en: "Postal" },
            "lblCity": { it: "Città", en: "City" },
            "lblRegionCode": { it: "Codice Regione", en: "Region code" },
            "lblRegion": { it: "Regione", en: "Region" },
            "lblCountryCode": { it: "Codice Nazione", en: "Country code" },
            "lblCountry": { it: "Nazione", en: "Country" },
            "lblContinentCode": { it: "Codice Continente", en: "Continent code" },
            "lblContinent": { it: "Continente", en: "Continent" },
            "msgClientDatetime": { it: "Data e ora (locale)", en: "Date Time (local)" },
            "msgServerDatetime": { it: "Data e ora, server: NTP", en: "Date time, server: NTP" },
            "lblDelete": { it: "🗑 Elimina", en: "🗑 Delete" },
            "lblReset": { it: "Reset dispositivo", en: "Device reset" },
            "msgScanWifiError": { it: "Errore caricamento reti WiFi", en: "Error loading WiFi networks" },
            "msgScanCompleted": { it: "Scan completato", en: "Scan completed" },
            "msgConnectionFailed": { it: "❌ Connessione fallita !", en: "❌ Connection failed !" },
            "msgConnectionSuccess": { it: "✔️ Connessione riuscita !", en: "✔️ Connection successful !" },
            "msgPostWifiSaving":     { it: "Il dispositivo verrà riavviato. Sarà disponibile in rete all'url '@@deviceUrl1@@' oppure '@@deviceUrl2@@'", en: "The device will reboot. It will be available online at '@@deviceUrl1@@' or '@@deviceUrl2@@'" },
            "lblCancel": { it: "Annulla", en: "Cancel" },
            "lblSaveWifi": { it: "Salvataggio rete wifi", en: "Saving Wi-Fi network" },
            "errSaveWifi": { it: "❌ E' necessario il test della rete", en: "❌ Network testing is required" },
            "msgApRestart": { it: "Riavviare il dispositivo ?\nPrima di poter riaprire questa pagina, sarà necessario collegarsi di nuovo al dispositivo.", en: "Restart device ?\nBefore you can reopen this page, you will need to connect to your device again." },
            "lblRestart": { it: "Riavvio", en: "Restart" },
            "msgTestRunning": { it: "Test già in corso.", en: "Testing already underway." },
            "msgNoWifiNet": { it: "Nessun a rete wifi rilevata", en: "No Wi-Fi network detected" },
            "lblApMode": { it: "Modalità Access Point", en: "Access Point Mode" },
            "lblNotConnected": { it: "Non connesso", en: "Not Connected" },
            "lblConnected": { it: "Connesso", en: "Connected" },
            "msgPswSaved": { it: "Password salvata, ricordarsi di eliminare la connessione sul dispositivo con la vecchia password.\nLe modifiche verranno applicate dopo il riavvio della scheda.", en: "Password saved, remember to delete the connection on the device with the old password.\nThe changes will take effect after you restart the device." },
            "errSsid": { it: "❌ Ssid ap almeno 4 caratteri alfanumerici, senza spazi o caratteri speciali", en: "❌ SSID ap at least 4 alphanumeric characters, without spaces or special characters" },
            "errPsw": { it: "❌ Password almeno 8 caratteri", en: "❌ Password at least 8 characters" },
            "errModuleNotFound":     { it: "❌ Attenzione, modulo '@@modulePath@@' non trovato !", en: "❌ Attention, module '@@modulePath@@' not found !" },
            "lblEvTimeLine":     { it: "🧩 Timeline eventi", en: "🧩 Events Timeline" },
            "lblBootTimeLine":     { it: "🚀 Timeline avvio sistema", en: "🚀 System Boot Timeline" },
            "lblSelectWifi":     { it: "Seleziona rete WiFi", en: "Select wifi net" },
            "lblSave":     { it: "Salva", en: "Save" },
            "lblOpMode":     { it: "Modalità operativa", en: "Operating mode" },
            "lbl_Conf":     { it: "Configurazione", en: "Configuration" },
            "lbl_Logs":     { it: "Logs", en: "Logs" },
            "lbl_Modules":     { it: "Moduli", en: "Modules" },
            "footerText":     { it: "Automazione e software per ogni esigenza.", en: "Automation and software for every need." },
            "lblCompany": { it: "Azienda", en: "Company" },
            "lblCode": { it: "Codice", en: "Code" },
            "lblModName": { it: "Nome modulo", en: "Module name" },
            "lblDevName": { it: "Nome dispositivo", en: "Device name" },
            "lblAcc": { it: "Accuratezza", en: "Accuracy" },
            "lblAlt": { it: "Altezza", en: "Altitude" },
            "lblLon": { it: "Longitudine", en: "Longitude" },
            "lblLat": { it: "Latitudine", en: "Latitude" },
            "lblLocalNet": { it: "Reti locali", en: "Local networks" },
            "lbl_Services": { it: "Servizi", en: "Services" },
            "lblMode": { it: "Modo operativo", en: "Mode" },
            "lblChipModel": { it: "Modello chip", en: "Chip model" },
            "lblUptime": { it: "Tempo da accensione", en: "Uptime" },
            "lblHeapFree": { it: "Heap libero", en: "Free heap" },
            "lblHeapSize": { it: "Dimens. Heap", en: "Heap size" },
            "lblFlaSpeed": { it: "Velocità Flash", en: "Flash speed" },
            "lblFlaSize": { it: "Dimens. Flash", en: "Flash size" },
            "lblChipRev": { it: "Rev. chip", en: "Chip rev." },
            "lblFirmVers": { it: "Vers. firmware", en: "Firmware vers." },
            "lblUpdateFw": { it: "Aggiornamento firmware", en: "Firmware update" },
            "lblKey": { it: "Chiave", en: "Key" },
            "lblName": { it: "Nome", en: "Name" },
            "lblLocalTime": { it: "Ora locale", en: "Local time" },
            "lblTimeUnix": { it: "Tempo (unix)", en: "Time (unix)" },
            "lblOffset": { it: "Diff.", en: "Offset" },
            "lblTimezone": { it: "Zona", en: "Timezone" },
            "lblWebCmd": { it: "Comandi web", en: "Web commands" },
            "lblDep": { it: "Dipendenze", en: "Dependency" },
            "lblState": { it: "Stato", en: "State" },
            "lblNoCommands": { it: "Nessun comando.", en: "No commands." },
            "lblNoDep": { it: "Nessuna dipendenza.", en: "No dependency." },
            "msgBuildUi": { it: "✔️ Creazione interfaccia.", en: "✔️ UI builds" },
            "msgDevErr":      { it: "❌ Il dispositivo non risponde.", en: "❌ The device is not responding." },
            "load_system":   { it: "Caricamento sistema...", en: "Loading system..." },
            "load_wifi":     { it: "Configurazione WiFi...", en: "Configuring WiFi..." },
            "load_services": { it: "Avvio servizi...", en: "Starting services..." },
            "load_modules":  { it: "Inizializzazione moduli...", en: "Initializing modules..." },
            "load_geo":      { it: "Localizzazione...", en: "Localization..." },
            "boot_ok":       { it: "Sistema Pronto", en: "System Ready" },
            "load_logs":     { it: "Recupero registri...", en: "Fetching logs..." },
            "load_web":      { it: "Analisi Web Server...", en: "Analyzing Web Server..." },
            "load_reset":    { it: "Controllo parametri reset...", en: "Checking reset params..." },
            "load_time":    { it: "Controllo parametri time...", en: "Checking time params..." },
            "lblMessage": { it: "Messaggio", en: "Message" },
            "lblTime": { it: "Tempo", en: "Time" },
            "lblSource": { it: "Sorgente", en: "Source" },
            "lblType": { it: "Tipo", en: "Type" },
            "lblRefresh": { it: "🔄 Aggiorna", en: "🔄 Refresh" },
            "msgDeleteLogs": { it: "Cancellare tutti i logs ?", en: "Delete all logs ?" },
            "msg_AP": { it: "Il dispositivo avvia un access point dedicato, con rete WiFi indipendente e isolata dalla LAN. " +
                             "Per configurarlo è sufficiente collegarsi all’AP ed aprire l’interfaccia web locale. " +
                                "Massimo livello di sicurezza per la rete domestica: il dispositivo non si collega a nessuna LAN. Funzionalità legate a data ed ora disattivate.",
                         en: "The device starts as a dedicated access point, exposing an independent WiFi network isolated from your LAN. " +
                                "To configure it, simply connect to the AP and open the local web interface. " +
                                "Maximum LAN security: the device does not connect to any existing network. Date and time related features disabled." },
            "msg_LAN": { it: "Il dispositivo opera come client della rete locale. " +
                                "È raggiungibile tramite l’indirizzo IP assegnato dal router (dopo il test di connessione). " +
                                "In questa modalità l’AP interno è disattivato. Funzionalità legate a data e ora attive, il dispositivo sincronizza tramite server ntp.",
                               en: "The device operates as a LAN client. " +
                                        "It is accessible via the IP assigned by your router (after the connection test). " +
                                        "The internal access point is disabled in this mode. Date and time related features are active, the device synchronizes via ntp server." },
            "msg_RESET": { it: "Il dispositivo verrà ripristinato con i  dati di fabbrica, connessione wifi e dati verranno cancellati",
                               en: "The device will be factory reset, wifi connection and data will be erased." },
            "msgUpdateFw": { it: "Il dispositivo verrà aggiornato alla nuova versione del firmware, i dati verranno mantenuti.",
                               en: "The device will be updated to the new firmware version, data will be preserved." }


        };



         this.flagSvgMap = {
                    it: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="15" viewBox="0 0 3 2">
                            <rect width="1" height="2" x="0" y="0" fill="#009246"/>
                            <rect width="1" height="2" x="1" y="0" fill="#fff"/>
                            <rect width="1" height="2" x="2" y="0" fill="#ce2b37"/>
                        </svg>`,
                    en: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="15" viewBox="0 0 60 30">
                            <clipPath id="t"><path d="M0,0 v30 h60 v-30 z"/></clipPath>
                            <clipPath id="s"><path d="M30,15 h30 v15 h-30 z v-15 h-30 v15 h30 z"/></clipPath>
                            <g clip-path="url(#t)">
                                <path d="M0,0 v30 h60 v-30 z" fill="#012169"/>
                                <path d="M0,0 l60,30 M60,0 l-60,30" stroke="#fff" stroke-width="6"/>
                                <path d="M0,0 l60,30 M60,0 l-60,30" stroke="#c8102e" stroke-width="4" clip-path="url(#s)"/>
                                <path d="M30,0 v30 M0,15 h60" stroke="#fff" stroke-width="10"/>
                                <path d="M30,0 v30 M0,15 h60" stroke="#c8102e" stroke-width="6"/>
                            </g>
                        </svg>`
                };





    }


/**
 * Aggiunge traduzioni custom provenienti dai moduli
 * @param {object} map Oggetto: { key: { it: "...", en: "..." } }
 */
addTranslations(map) {
    if (!map || typeof map !== "object") return;

    for (const key in map) {
        if (!map[key]) continue;

        // Se la chiave esiste già, la estendiamo
        if (this.contents[key]) {
            this.contents[key] = {
                ...this.contents[key],
                ...map[key]
            };
        } else {
            // Nuova chiave
            this.contents[key] = map[key];
        }
    }
}


    /**
     * Imposta la lingua corrente
     * @param {string} lng "IT" o "EN"
     */
        setLanguage(lng) {
            const lowerLng = lng.toLowerCase();
            const valid = this.languages.map(l => l.toLowerCase());
            if (valid.includes(lowerLng)) {
                this.currentLng = lowerLng;
               // console.log(`Translator: Lingua impostata su ${this.currentLng}`);
            } else {
               // console.warn(`Translator: Codice lingua non valido: ${lng}`);
            }
        }


        getLanguage() { return this.currentLng; }


    /**
     * Recupera il contenuto tradotto (il tuo findKey)
     * @param {string} key La chiave della traduzione
     * @returns {string} Testo tradotto o la chiave stessa se non trovata
     */
    tr(key) {
        const entry = this.contents[key];
        if (!entry) {
            //console.warn(`Translator: Key '${key}' not found`);
            return key;
        }
        const text = entry[this.currentLng.toLowerCase()];
        return text || entry["en"]; // Fallback su inglese
    }

    /**
     * Traduce automaticamente tutti gli elementi nel DOM con attributo data-tr
     * Esempio: <span data-tr="lblInfoName"></span>
     */
    translatePage() {
        const elements = document.querySelectorAll('[data-tr]');
        elements.forEach(el => {
            const key = el.getAttribute('data-tr');
            el.innerText = this.tr(key);
        });
    }


    translateDiv(divId) {
        const container = document.getElementById(divId);
        if (!container) return; // div non trovato, esco in silenzio

        const elements = container.querySelectorAll('[data-tr]');
        elements.forEach(el => {
            const key = el.getAttribute('data-tr');
            if (!key) return; // sicurezza extra
            el.innerText = this.tr(key);
        });
    }



getLanguages() {
    return this.languages.map(code => {
        const lower = code.toLowerCase();
        return {
            code: lower,
            label: code.toUpperCase(),
            flagSvg: this.flagSvgMap[lower] || ""
        };
    });
}


getFlagEmoji(code) {
    if (!code || typeof code !== "string" || code.length !== 2) return "🏳️";
    const cc = code.toUpperCase();
    return [...cc].map(c =>
        String.fromCodePoint(0x1F1E6 + c.charCodeAt(0) - 65)
    ).join("");
}




initLanguageSelector() {
    const container = document.getElementById("langDropdownContainer");
    const btn = document.getElementById("langDropdownBtn");
    const menu = document.getElementById("langDropdownMenu");
    if (!container || !btn || !menu) {
        console.error("Dropdown lingua non trovato");
        return;
    }

    const langs = this.getLanguages();
    const savedLng = (localStorage.getItem("lang") || "en").toLowerCase();
    const validCodes = langs.map(l => l.code);
    const initialLng = validCodes.includes(savedLng) ? savedLng : "en";

    const setLang = (lng) => {
        loader(true);
        const lang = langs.find(l => l.code === lng);
        if (!lang) return;
        localStorage.setItem("lang", lang.code);
        this.setLanguage(lang.code);
        this.translatePage();
        btn.innerHTML = `<span class="flag-icon me-1">${lang.flagSvg}</span> ${lang.label}`;
        //toast(this.tr("msgCmdExecuted"), "success");
        updateFooter();
        loader(false);
    };

    // Popola il menu
    menu.innerHTML = "";
    langs.forEach(({ code, label, flagSvg }) => {
        const li = document.createElement("li");
        li.innerHTML = `
            <a class="dropdown-item d-flex align-items-center gap-2" href="#">
                <span class="flag-icon">${flagSvg}</span>
                <span>${label}</span>
            </a>`;
        li.addEventListener("click", () => setLang(code));
        menu.appendChild(li);
    });


    // Imposta lingua iniziale
    setLang(initialLng);
}







}