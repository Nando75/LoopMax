import { toast, loader, updateFooter, sendAPI  } from './LoopMaxUtils.js';
export class Translator {

    constructor() {
        this.listeners = new Set();
        this.currentLng = "en"; // Default
        this.languages = ["it", "en", "es"];

        this.contents = {
            "lblInfoName":    { it: "Nome", en: "Name", es: "Nombre" },
            "lblInfoCode":    { it: "Codice", en: "Code", es: "Código" },
            "lblInfoIP":      { it: "Indirizzo Ip", en: "Ip Address", es: "Dirección IP" },
            "lblInfoFW":      { it: "Versione Firmware", en: "Firmware Version", es: "Versión del firmware" },
            "lblInfoMode":    { it: "Modalità operativa", en: "Operating mode", es: "Modo operativo" },
            "lblInfoLng":     { it: "Lingua", en: "Language", es: "Idioma" },
            "lblChann":       { it: "Canali", en: "Channels", es: "Canales" },
            "lblInfoCompany": { it: "Azienda", en: "Company", es: "Empresa" },
            "btInfoRed":      { it: "Rete", en: "Network", es: "Red" },
            "btInfoGen":      { it: "Dispositivo", en: "Device", es: "Dispositivo" },
            "tabInfoTitle":   { it: "Informazioni Dispositivo", en: "Device informations", es: "Información del dispositivo" },
            "msgCmdExecuted": { it: "✔️ Comando eseguito.", en: "✔️ Command executed", es: "✔️ Comando ejecutado." },
            "errCmdNotExecuted": { it: "❌ Comando non eseguito.", en: "❌ Command not executed", es: "❌ Comando no ejecutado." },
            "lblRestarting": { it: "✔️ Riavvio in corso ...", en: "✔️ Restarting ...", es: "✔️ Reiniciando..." },
            "lblLoginok": { it: "✔️ Accesso riuscito,\nattendere caricamento pagina", en: "✔️ Login successful, page loading.", es: "✔️ Acceso correcto, cargando página." },
            "lblLoginFailed": { it: "❌ Accesso non riuscito", en: "❌ Login failed", es: "❌ Acceso fallido" },
            "lbl_Login": { it: "🔐 Login utente", en: "🔐 User login", es: "🔐 Inicio de sesión" },
            "lblLocalIp": { it: "Ip locale", en: "Local Ip", es: "IP local" },
            "lblPublicIp": { it: "Ip pubblico", en: "Public Ip", es: "IP pública" },
            "lblCapital": { it: "Capitale", en: "Capital", es: "Capital" },
            "lblPostal": { it: "Cod. postale", en: "Postal", es: "Código postal" },
            "lblCity": { it: "Città", en: "City", es: "Ciudad" },
            "lblRegionCode": { it: "Codice Regione", en: "Region code", es: "Código de región" },
            "lblRegion": { it: "Regione", en: "Region", es: "Región" },
            "lblCountryCode": { it: "Codice Nazione", en: "Country code", es: "Código de país" },
            "lblCountry": { it: "Nazione", en: "Country", es: "País" },
            "lblContinentCode": { it: "Codice Continente", en: "Continent code", es: "Código de continente" },
            "lblContinent": { it: "Continente", en: "Continent", es: "Continente" },
            "msgClientDatetime": { it: "Data e ora (locale)", en: "Date Time (local)", es: "Fecha y hora (local)" },
            "msgServerDatetime": { it: "Data e ora, server: NTP", en: "Date time, server: NTP", es: "Fecha y hora, servidor: NTP" },
            "lblDelete": { it: "🗑 Elimina", en: "🗑 Delete", es: "🗑 Eliminar" },
            "lblReset": { it: "Reset dispositivo", en: "Device reset", es: "Restablecer dispositivo" },
            "msgScanWifiError": { it: "Errore caricamento reti WiFi", en: "Error loading WiFi networks", es: "Error al cargar redes WiFi" },
            "msgScanCompleted": { it: "Scan completato", en: "Scan completed", es: "Escaneo completado" },
            "msgConnectionFailed": { it: "❌ Connessione fallita !", en: "❌ Connection failed !", es: "❌ Conexión fallida !" },
            "msgConnectionSuccess": { it: "✔️ Connessione riuscita !", en: "✔️ Connection successful !", es: "✔️ Conexión exitosa !" },
            "msgPostWifiSaving": {
                it: "Il dispositivo verrà riavviato. Sarà disponibile in rete all'url '@@deviceUrl1@@' oppure '@@deviceUrl2@@'",
                en: "The device will reboot. It will be available online at '@@deviceUrl1@@' or '@@deviceUrl2@@'",
                es: "El dispositivo se reiniciará. Estará disponible en la red en '@@deviceUrl1@@' o '@@deviceUrl2@@'"
            },
            "lblCancel": { it: "Annulla", en: "Cancel", es: "Cancelar" },
            "lblSaveWifi": { it: "Salvataggio rete wifi", en: "Saving Wi-Fi network", es: "Guardando red Wi‑Fi" },
            "errSaveWifi": { it: "❌ E' necessario il test della rete", en: "❌ Network testing is required", es: "❌ Es necesario probar la red" },
            "msgApRestart": {
                it: "Riavviare il dispositivo ?\nPrima di poter riaprire questa pagina, sarà necessario collegarsi di nuovo al dispositivo.",
                en: "Restart device ?\nBefore you can reopen this page, you will need to connect to your device again.",
                es: "¿Reiniciar el dispositivo?\nAntes de reabrir esta página, será necesario volver a conectarse al dispositivo."
            },
            "lblRestart": { it: "Riavvio", en: "Restart", es: "Reiniciar" },
            "msgTestRunning": { it: "Test già in corso.", en: "Testing already underway.", es: "Prueba ya en curso." },
            "msgNoWifiNet": { it: "Nessun a rete wifi rilevata", en: "No Wi-Fi network detected", es: "No se detectó ninguna red Wi‑Fi" },
            "lblApMode": { it: "Modalità Access Point", en: "Access Point Mode", es: "Modo punto de acceso" },
            "lblNotConnected": { it: "Non connesso", en: "Not Connected", es: "No conectado" },
            "lblConnected": { it: "Connesso", en: "Connected", es: "Conectado" },
            "msgPswSaved": {
                it: "Password salvata, ricordarsi di eliminare la connessione sul dispositivo con la vecchia password.\nLe modifiche verranno applicate dopo il riavvio della scheda.",
                en: "Password saved, remember to delete the connection on the device with the old password.\nThe changes will take effect after you restart the device.",
                es: "Contraseña guardada, recuerda eliminar la conexión en el dispositivo con la contraseña antigua.\nLos cambios se aplicarán tras reiniciar el dispositivo."
            },
            "errSsid": {
                it: "❌ Ssid ap almeno 4 caratteri alfanumerici, senza spazi o caratteri speciali",
                en: "❌ SSID ap at least 4 alphanumeric characters, without spaces or special characters",
                es: "❌ SSID ap de al menos 4 caracteres alfanuméricos, sin espacios ni caracteres especiales"
            },
            "errPsw": {
                it: "❌ Password almeno 8 caratteri",
                en: "❌ Password at least 8 characters",
                es: "❌ Contraseña de al menos 8 caracteres"
            },
            "errModuleNotFound": {
                it: "❌ Attenzione, modulo '@@modulePath@@' non trovato !",
                en: "❌ Attention, module '@@modulePath@@' not found !",
                es: "❌ Atención, módulo '@@modulePath@@' no encontrado !"
            },
            "lblEvTimeLine": { it: "🧩 Timeline eventi", en: "🧩 Events Timeline", es: "🧩 Línea temporal de eventos" },
            "lblBootTimeLine": { it: "🚀 Timeline avvio sistema", en: "🚀 System Boot Timeline", es: "🚀 Línea temporal de arranque del sistema" },
            "lblSelectWifi": { it: "Seleziona rete WiFi", en: "Select wifi net", es: "Seleccionar red Wi‑Fi" },
            "lblSave": { it: "Salva", en: "Save", es: "Guardar" },
            "lblOpMode": { it: "Modalità operativa", en: "Operating mode", es: "Modo operativo" },
            "lbl_Conf": { it: "Configurazione", en: "Configuration", es: "Configuración" },
            "lbl_Logs": { it: "Logs", en: "Logs", es: "Registros" },
            "lbl_Modules": { it: "Moduli", en: "Modules", es: "Módulos" },
            "footerText": {
                it: "Automazione e software per ogni esigenza.",
                en: "Automation and software for every need.",
                es: "Automatización y software para cada necesidad."
            },
            "lblCompany": { it: "Azienda", en: "Company", es: "Empresa" },
            "lblCode": { it: "Codice", en: "Code", es: "Código" },
            "lblModName": { it: "Nome modulo", en: "Module name", es: "Nombre del módulo" },
            "lblDevName": { it: "Nome dispositivo", en: "Device name", es: "Nombre del dispositivo" },
            "lblAcc": { it: "Accuratezza", en: "Accuracy", es: "Precisión" },
            "lblAlt": { it: "Altezza", en: "Altitude", es: "Altitud" },
            "lblLon": { it: "Longitudine", en: "Longitude", es: "Longitud" },
            "lblLat": { it: "Latitudine", en: "Latitude", es: "Latitud" },
            "lblLocalNet": { it: "Reti locali", en: "Local networks", es: "Redes locales" },
            "lbl_Services": { it: "Servizi", en: "Services", es: "Servicios" },
            "lblMode": { it: "Modo operativo", en: "Mode", es: "Modo" },
            "lblChipModel": { it: "Modello chip", en: "Chip model", es: "Modelo de chip" },
            "lblUptime": { it: "Tempo da accensione", en: "Uptime", es: "Tiempo encendido" },
            "lblHeapFree": { it: "Heap libero", en: "Free heap", es: "Heap libre" },
            "lblHeapSize": { it: "Dimens. Heap", en: "Heap size", es: "Tamaño del heap" },
            "lblFlaSpeed": { it: "Velocità Flash", en: "Flash speed", es: "Velocidad de la flash" },
            "lblFlaSize": { it: "Dimens. Flash", en: "Flash size", es: "Tamaño de la flash" },
            "lblChipRev": { it: "Rev. chip", en: "Chip rev.", es: "Rev. chip" },
            "lblFirmVers": { it: "Vers. firmware", en: "Firmware vers.", es: "Vers. firmware" },
            "lblUpdateFw": { it: "Aggiornamento firmware", en: "Firmware update", es: "Actualización de firmware" },
            "lblKey": { it: "Chiave", en: "Key", es: "Clave" },
            "lblName": { it: "Nome", en: "Name", es: "Nombre" },
            "lblLocalTime": { it: "Ora locale", en: "Local time", es: "Hora local" },
            "lblTimeUnix": { it: "Tempo (unix)", en: "Time (unix)", es: "Tiempo (unix)" },
            "lblOffset": { it: "Diff.", en: "Offset", es: "Desfase" },
            "lblTimezone": { it: "Zona", en: "Timezone", es: "Zona horaria" },
            "lblWebCmd": { it: "Comandi web", en: "Web commands", es: "Comandos web" },
            "lblDep": { it: "Dipendenze", en: "Dependency", es: "Dependencias" },
            "lblState": { it: "Stato", en: "State", es: "Estado" },
            "lblNoCommands": { it: "Nessun comando.", en: "No commands.", es: "Sin comandos." },
            "lblNoDep": { it: "Nessuna dipendenza.", en: "No dependency.", es: "Sin dependencias." },
            "msgBuildUi": { it: "✔️ Creazione interfaccia.", en: "✔️ UI builds", es: "✔️ Creazione interfaccia." },
            "msgDevErr": { it: "❌ Il dispositivo non risponde.", en: "❌ The device is not responding.", es: "❌ El dispositivo no responde." },
            "load_system":   { it: "Caricamento sistema...", en: "Loading system...", es: "Cargando sistema..." },
            "load_wifi":     { it: "Configurazione WiFi...", en: "Configuring WiFi...", es: "Configurando Wi‑Fi..." },
            "load_services": { it: "Avvio servizi...", en: "Starting services...", es: "Iniciando servicios..." },
            "load_modules":  { it: "Inizializzazione moduli...", en: "Initializing modules...", es: "Inicializando módulos..." },
            "load_geo":      { it: "Localizzazione...", en: "Localization...", es: "Localización..." },
            "boot_ok":       { it: "Sistema Pronto", en: "System Ready", es: "Sistema listo" },
            "load_logs":     { it: "Recupero registri...", en: "Fetching logs...", es: "Recuperando registros..." },
            "load_web":      { it: "Analisi Web Server...", en: "Analyzing Web Server...", es: "Analizando servidor web..." },
            "load_reset":    { it: "Controllo parametri reset...", en: "Checking reset params...", es: "Comprobando parámetros de reinicio..." },
            "load_time":     { it: "Controllo parametri time...", en: "Checking time params...", es: "Comprobando parámetros de tiempo..." },
            "lblMessage": { it: "Messaggio", en: "Message", es: "Mensaje" },
            "lblTime": { it: "Tempo", en: "Time", es: "Tiempo" },
            "lblSource": { it: "Sorgente", en: "Source", es: "Fuente" },
            "lblType": { it: "Tipo", en: "Type", es: "Tipo" },
            "lblRefresh": { it: "🔄 Aggiorna", en: "🔄 Refresh", es: "🔄 Actualizar" },
            "msgDeleteLogs": { it: "Cancellare tutti i logs ?", en: "Delete all logs ?", es: "¿Eliminar todos los logs?" },
            "lblLogin": { it:"Accesso utente", en:"User login", es:"Inicio de sesión" },
            "msg_AP": {
                it: "Il dispositivo avvia un access point dedicato, con rete WiFi indipendente e isolata dalla LAN. " +
                    "Per configurarlo è sufficiente collegarsi all’AP ed aprire l’interfaccia web locale. " +
                    "Massimo livello di sicurezza per la rete domestica: il dispositivo non si collega a nessuna LAN. Funzionalità legate a data ed ora disattivate.",
                en: "The device starts as a dedicated access point, exposing an independent WiFi network isolated from your LAN. " +
                    "To configure it, simply connect to the AP and open the local web interface. " +
                    "Maximum LAN security: the device does not connect to any existing network. Date and time related features disabled.",
                es: "El dispositivo inicia como un punto de acceso dedicado, con una red Wi‑Fi independiente y aislada de la LAN. " +
                    "Para configurarlo, basta conectarse al AP y abrir la interfaz web local. " +
                    "Máxima seguridad para la red doméstica: el dispositivo no se conecta a ninguna LAN existente. Funciones relacionadas con fecha y hora desactivadas."
            },
            "msg_LAN": {
                it: "Il dispositivo opera come client della rete locale. " +
                    "È raggiungibile tramite l’indirizzo IP assegnato dal router (dopo il test di connessione). " +
                    "In questa modalità l’AP interno è disattivato. Funzionalità legate a data e ora attive, il dispositivo sincronizza tramite server ntp.",
                en: "The device operates as a LAN client. " +
                    "It is accessible via the IP assigned by your router (after the connection test). " +
                    "The internal access point is disabled in this mode. Date and time related features are active, the device synchronizes via ntp server.",
                es: "El dispositivo opera como cliente de la red local. " +
                    "Es accesible mediante la IP asignada por el router (después de la prueba de conexión). " +
                    "En este modo, el punto de acceso interno está desactivado. Las funciones relacionadas con fecha y hora están activas y el dispositivo se sincroniza mediante un servidor NTP."
            },
            "msg_RESET": {
                it: "Il dispositivo verrà ripristinato con i  dati di fabbrica, connessione wifi e dati verranno cancellati",
                en: "The device will be factory reset, wifi connection and data will be erased.",
                es: "El dispositivo se restablecerá a los valores de fábrica, la conexión Wi‑Fi y los datos serán eliminados."
            },
            "msgUpdateFw": {
                it: "Il dispositivo verrà aggiornato alla nuova versione del firmware, i dati verranno mantenuti. Attendere un paio di minuti prima di aggiornare la pagina.",
                en: "The device will be updated to the new firmware version, data will be preserved. Please wait a couple of minutes before refreshing the page.",
                es: "El dispositivo se actualizará a la nueva versión del firmware, los datos se conservarán. Espere un par de minutos antes de actualizar la página."
            }
        };

        this.flagSvgMap = {
            it: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="15" viewBox="0 0 3 2">
                    <rect width="1" height="2" x="0" y="0" fill="#009246"/>
                    <rect width="1" height="2" x="1" y="0" fill="#fff"/>
                    <rect width="1" height="2" x="2" y="0" fill="#ce2b37"/>
                </svg>`,
            en: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="15" viewBox="0 0 60 30">
                    <clipPath id="t"><path d="M0,0 v30 h60 v-30 z"/></clipPath>
                    <clipPath id="s"><path d="M30,15 h30 v15 h-30 z v-15 h-30 v15 h30 z"/></clipPath>
                    <g clip-path="url(#t)">
                        <path d="M0,0 v30 h60 v-30 z" fill="#012169"/>
                        <path d="M0,0 l60,30 M60,0 l-60,30" stroke="#fff" stroke-width="6"/>
                        <path d="M0,0 l60,30 M60,0 l-60,30" stroke="#c8102e" stroke-width="4" clip-path="url(#s)"/>
                        <path d="M30,0 v30 M0,15 h60" stroke="#fff" stroke-width="10"/>
                        <path d="M30,0 v30 M0,15 h60" stroke="#c8102e" stroke-width="6"/>
                    </g>
                </svg>`,
            es: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="15" viewBox="0 0 3 2">
                    <rect width="3" height="2" fill="#AA151B"/>
                    <rect y="0.5" width="3" height="1" fill="#F1BF00"/>
                </svg>`
        };
    }


/**
 * Aggiunge traduzioni custom provenienti dai moduli
 * @param {object} map Oggetto: { key: { it: "...", en: "..." } }
 */
addTranslations(map) {
    if (!map || typeof map !== "object") return;

    for (const key in map) {
        if (!map[key]) continue;

        // Se la chiave esiste già, la estendiamo
        if (this.contents[key]) {
            this.contents[key] = {
                ...this.contents[key],
                ...map[key]
            };
        } else {
            // Nuova chiave
            this.contents[key] = map[key];
        }
    }
}


    /**
     * Imposta la lingua corrente
     * @param {string} lng "IT" o "EN"
     */
        setLanguage(lng) {
            const lowerLng = lng.toLowerCase();
            const valid = this.languages.map(l => l.toLowerCase());
            if (valid.includes(lowerLng)) {
                this.currentLng = lowerLng;
               // console.log(`Translator: Lingua impostata su ${this.currentLng}`);
            } else {
               // console.warn(`Translator: Codice lingua non valido: ${lng}`);
            }
        }


        getLanguage() { return this.currentLng; }


    /**
     * Recupera il contenuto tradotto (il tuo findKey)
     * @param {string} key La chiave della traduzione
     * @returns {string} Testo tradotto o la chiave stessa se non trovata
     */
    tr(key) {
        const entry = this.contents[key];
        if (!entry) {
            //console.warn(`Translator: Key '${key}' not found`);
            return key;
        }
        const text = entry[this.currentLng.toLowerCase()];
        return text || entry["en"]; // Fallback su inglese
    }

    /**
     * Traduce automaticamente tutti gli elementi nel DOM con attributo data-tr
     * Esempio: <span data-tr="lblInfoName"></span>
     */
    translatePage() {
        const elements = document.querySelectorAll('[data-tr]');
        elements.forEach(el => {
            const key = el.getAttribute('data-tr');
            el.innerText = this.tr(key);
        });
         this._notifyLanguageChanged();
    }


    translateDiv(divId) {
        const container = document.getElementById(divId);
        if (!container) return; // div non trovato, esco in silenzio

        const elements = container.querySelectorAll('[data-tr]');
        elements.forEach(el => {
            const key = el.getAttribute('data-tr');
            if (!key) return; // sicurezza extra
            el.innerText = this.tr(key);
        });
    }



getLanguages() {
    return this.languages.map(code => {
        const lower = code.toLowerCase();
        return {
            code: lower,
            label: code.toUpperCase(),
            flagSvg: this.flagSvgMap[lower] || ""
        };
    });
}


getFlagEmoji(code) {
    if (!code || typeof code !== "string" || code.length !== 2) return "🏳️";
    const cc = code.toUpperCase();
    return [...cc].map(c =>
        String.fromCodePoint(0x1F1E6 + c.charCodeAt(0) - 65)
    ).join("");
}

initLanguageSelector() {
    const container = document.getElementById("langDropdownContainer");
    const btn = document.getElementById("langDropdownBtn");
    const menu = document.getElementById("langDropdownMenu");

    if (!container || !btn || !menu) {
        console.error("Dropdown lingua non trovato");
        return;
    }

    const langs = this.getLanguages();

    // -------- UI INIT (NO API) --------
    const current = langs.find(l => l.code === this.currentLng);
    if (current) {
        btn.innerHTML = `
            <span class="flag-icon me-1">${current.flagSvg}</span> ${current.label}
        `;
    }

    // -------- MENU BUILD --------
    menu.innerHTML = "";

    langs.forEach(({ code, label, flagSvg }) => {
        const li = document.createElement("li");

        li.innerHTML = `
            <a class="dropdown-item d-flex align-items-center gap-2" href="#">
                <span class="flag-icon">${flagSvg}</span>
                <span>${label}</span>
            </a>`;

        // 🔥 UNA SOLA COSA
        li.addEventListener("click", () => this.setLang(code));

        menu.appendChild(li);
    });
}



register(listener) {
    if (!listener) return;
    this.listeners.add(listener);
}

unregister(listener) {
    this.listeners.delete(listener);
}


_notifyLanguageChanged() {
    for (const listener of this.listeners) {
        try {
            // supporta:
            // - funzione semplice
            // - oggetto con metodo onLanguageChange
            if (typeof listener === "function") {
                listener(this.currentLng);
            } else if (typeof listener.onLanguageChange === "function") {
                listener.onLanguageChange(this.currentLng);
            }
        } catch (e) {
            console.error("Translator listener error:", e);
        }
    }
}


/*
async setLang(lng) {
    loader(true);
    try {
        const form = new URLSearchParams();
        form.append("lng", lng);
        await sendAPI("conf/set/language", {
            method: "POST",
            body: form.toString(),
            return: "text"
        });
        // aggiorno translator + UI SOLO se API ok
        this.setLanguage(lng);
        this.translatePage();
        updateFooter();
        toast(this.tr("msgCmdExecuted"), "success");
    } catch (err) {
        toast(err.message || err, "danger");
    } finally {
        loader(false);
    }
}
*/

async setLang(lng) {
    loader(true);

    try {
        const form = new URLSearchParams();
        form.append("lng", lng);

        await sendAPI("conf/set/language", {
            method: "POST",
            body: form.toString(),
            return: "text"
        });

        // stato interno
        this.setLanguage(lng);

        // traduci
        this.translatePage();
        updateFooter();

        // 🔥 AGGIORNA DROPDOWN BUTTON
        const btn = document.getElementById("langDropdownBtn");
        const lang = this.getLanguages().find(l => l.code === lng);

        if (btn && lang) {
            btn.innerHTML = `
                <span class="flag-icon me-1">${lang.flagSvg}</span> ${lang.label}
            `;
        }

        toast(this.tr("msgCmdExecuted"), "success");

    } catch (err) {
        toast(err.message || err, "danger");
    } finally {
        loader(false);
    }
}








}