import { loader, toast, wifi, system, translator, modules, sendAPI, fetchAPI } from './LoopMaxUtils.js';

export class Configuration {
    constructor() {
        this.wifi = wifi();
        this.system = system();
        this.modules = modules();
        this.isValidWifi = false;        
        this.wifiIP="";
    }


    getHtml() {
        let currForm="";
        const mode = this.system.getMode();
        if(mode=='AP') { currForm = this.getAPForm(); }
        if(mode=='LAN') { currForm = this.getWifiForm(); }
         const res = `<h5 class='secondFont' data-tr="lblOpMode"></h5>
                <div class="mb-3">
                    <div class="btn-group" role="group" aria-label="Mode selection">
                        <input type="radio" class="btn-check" name="modeOptions"
                            id="modeAP" value="AP" autocomplete="off"
                            ${mode === 'AP' ? 'checked' : ''}>
                        <label class="btn btn-outline-primary" for="modeAP">AP</label>
                        <input type="radio" class="btn-check" name="modeOptions"
                            id="modeLAN" value="LAN" autocomplete="off"
                            ${mode === 'LAN' ? 'checked' : ''}>
                        <label class="btn btn-outline-primary" for="modeLAN">LAN</label>
                        <input type="radio" class="btn-check" name="modeOptions"
                            id="modeReset" value="RESET" autocomplete="off" >
                        <label class="btn btn-outline-primary" for="modeReset">RESET</label>
                    </div>
                </div>
                <div id="divCurrForm">${currForm}</div>
                <div id="lanMsg" class="small text-muted mt-2 mb-2" data-tr="msg_AP"></div>`;
            return res;
    }



    initObjects() {
        this.updateWifiForm();
        
    }

        // ======================== FORM WIFI =====================
    updateWifiForm() {
        const mode = this.getSelectedMode();
        
        let currForm="";
        if(mode==="AP") { currForm = this.getAPForm(); }
        if(mode==="LAN") { currForm = this.getWifiForm(); }
        if(mode==="RESET") { currForm = this.getResetForm(); }
        const container = document.getElementById("divCurrForm");
        if(container) container.innerHTML = currForm;
        this.updateModeMessage(mode);
        if(mode=="LAN") this.refreshLocalWifi();
        this.refreshObjEvents(mode);
        
    }

    getSelectedMode() {
        const sel = document.querySelector('input[name="modeOptions"]:checked');
        return sel ? sel.value : "AP";
    }


    updateModeMessage(mode) {
    const msgEl = document.getElementById("lanMsg");
    if (!msgEl) return;
        msgEl.removeAttribute("data-tr");
        msgEl.dataset.tr = "msg_" + mode;
        if (mode === "AP") {
            msgEl.className = "small text-warning mt-2";
        } else if (mode === "LAN") {
            msgEl.className = "small text-success mt-2";
        } else if (mode === "RESET") {
            msgEl.className = "small text-info mt-2";
        } else {
            msgEl.className = "small text-muted mt-2";
        }
        // Ritraduci solo questo elemento (più efficiente)
        msgEl.innerHTML = translator.tr("msg_" + mode);
    }



    getResetForm()
        {
            const lblReset = translator.tr("lblReset");
            const lblCancel = translator.tr("lblCancel");

            return `<div class="card">
                        <div class="card-body">
                            <button id="btModalReset" type="button" class="btn btn-warning" data-tr="lblReset" data-bs-toggle="modal" data-bs-target="#modalReset">${lblReset}</button>
                        </div>
                    </div>
                    <div class="modal fade" id="modalReset" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="modalResetLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="modalResetLabel" data-tr="lblReset">${lblReset}</h1>
                            <button type="button" id="btResetClose1" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body" id='modalResetBody' data-tr="msg_RESET">
                        </div>
                        <div class="modal-footer">
                            <button type="button" id="btResetClose2" class="btn btn-secondary" data-bs-dismiss="modal" data-tr="lblCancel">${lblCancel}</button>
                            <button type="button" id="btReset" class="btn btn-primary" data-tr="lblReset">${lblReset}</button>
                        </div>
                        </div>
                    </div>
                    </div>`;
        }



    getWifiForm()
    {
        

        const lblSave = translator.tr("lblSave");
        const lblCancel = translator.tr("lblCancel");
        const modalHeader = translator.tr("lblSaveWifi");

        const mode = this.system.getMode();
        let status = "";
        if(mode=='LAN') { status = "disabled"; }
                
        const wfPsw = this.wifi.wfPsw;
        return `
        <form id="wifiForm">
            <div class="mb-3">
            <!-- Riga 1: label + badge -->
            <div class="d-flex align-items-center mb-1">
                <label for="wifiList" class="form-label me-2 mb-0">SSID</label>
                <small class="ms-2 badge bg-secondary" id="wifiQuality"></small>
            </div>
            <div class="d-flex gap-2">
                <select id="wifiList" class="form-select flex-grow-1" ${status}>
                <option selected disabled data-tr="lblSelectWifi">Seleziona rete WiFi</option>
                </select>
                <button type="button" class="btn btn-sm btn-outline-primary" id="scanBtn" ${status}>🔄 Scan</button>
            </div>
            </div>

            <div class="d-flex align-items-center mb-1">
                <label for="pwd" class="form-label">Password</label>
            </div>

            <div class="input-group mb-3">
                <input type="password" class="form-control" id="pwd" placeholder="Password" value="${wfPsw}" ${status}>
                <button class="btn btn-outline-secondary" type="button" id="togglePwd">👁️</button>
                <button type="button" class="btn btn-sm btn-outline-primary" id="testBtn" ${status}>📡 Test</button>
            </div>
            <div id="wifiTestStatus" class="mt-2"></div>
            <button id="btModalSaveWifi" type="button" class="btn btn-primary" data-tr="lblSave" disabled data-bs-toggle="modal" data-bs-target="#modalSaveWifi" ${status}>${lblSave}</button>
        </form>
        <div class="modal fade" id="modalSaveWifi" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="modalSaveWifiLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="modalSaveWifiLabel" data-tr="lblSaveWifi">${modalHeader}</h1>
                <button type="button" id="btCloseSaveWifi1" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id='modalBody'>
            </div>
            <div class="modal-footer">
                <button type="button" id="btCloseSaveWifi2" class="btn btn-secondary" data-bs-dismiss="modal" data-tr="lblCancel">${lblCancel}</button>
                <button type="button" id="btSaveWifi" class="btn btn-primary" data-tr="lblSave">${lblSave}</button>
            </div>
            </div>
        </div>
        </div>`;

    }

    
        getAPForm()
        {
            const lblSave = translator.tr("lblSave");
            const lblRestart = translator.tr("lblRestart");
            const lblCancel = translator.tr("lblCancel");
            const apSsid = this.wifi.apSsid;
            const apPsw = this.wifi.apPsw;
                    return `
                    <form id="apForm">
                        <div class="mb-3">
                        
                            <div class="d-flex align-items-center mb-1">
                                <label for="ssidAp" class="form-label">Ssid</label>
                            </div>
                            <div class="input-group mb-1">
                                <input type="text" class="form-control" id="ssidAp" value="${apSsid}"  minlength="4">
                            </div>

                            <div class="d-flex align-items-center mb-1">
                                <label for="pwdAp" class="form-label">Passowrd</label>
                            </div>

                            <div class="input-group mb-3">
                                <input type="password" class="form-control" id="pwdAp" placeholder="Password" value="${apPsw}" minlength="8">
                                <button class="btn btn-outline-secondary" type="button" id="togglePwd2">👁️</button>
                            </div>

                            <button id="btSaveApPsw" type="button" class="btn btn-primary" data-tr="lblSave">${lblSave}</button>
                            <button id="btModalRestart" type="button" disabled class="btn btn-primary" data-tr="lblRestart" data-bs-toggle="modal" data-bs-target="#modalRestart">${lblRestart}</button>
                        </div>
                    </form>

                    <div class="modal fade" id="modalRestart" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="modalRestartabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="modalRestartabel" data-tr="lblRestart">${lblRestart}</h1>
                                <button type="button" id="btCancelRestart1" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body" id='modalRestartBody'>
                            </div>
                            <div class="modal-footer">
                                <button type="button" id="btCancelRestart2" class="btn btn-secondary" data-bs-dismiss="modal" data-tr="lblCancel">${lblCancel}</button>
                                <button type="button" id="btRestart" class="btn btn-primary" data-tr="lblSave">${lblRestart}</button>
                            </div>
                            </div>
                        </div>
                    </div>`;

        }

      async saveAp() {
                loader(true);
                try {
                    const apSsid = this.wifi.apSsid;
                    const txtSsid = document.getElementById("ssidAp");
                    const conSsid = txtSsid.value;
                    const valid = /^[A-Za-z0-9]+$/.test(conSsid);
                    if (!conSsid || !valid) 
                    {
                        txtSsid.value=apSsid;
                        toast(translator.tr("errSsid"));
                        txtSsid.focus();
                        return;
                    }
                     if (conSsid.length < 4) {
                        toast(translator.tr("errSsid"));
                        txtSsid.focus();
                        return;
                    }

                    const apPsw = this.wifi.apPsw;
                    const txtPsw = document.getElementById("pwdAp");
                    if (!txtPsw) return;

                    const content = txtPsw.value;
                    if (!content) 
                    {
                        txtPsw.value=apPsw;
                        return;
                    }
                        
                    if (conSsid == apSsid && apPsw === content) return;

                    if (content.length < 8) {
                        toast(translator.tr("errPsw"));
                        txtPsw.focus();
                        return;
                    }

                    const form = new URLSearchParams();
                    form.append("apSsid", conSsid);
                    form.append("apPsw", content);

                    const res = await sendAPI("conf/save/ap", {
                        method: "POST",
                        body: form.toString(),
                        return: "text"
                    });

                    if (res === 'ok') {
                        this.wifi.apSsid = conSsid;
                        this.wifi.apPsw = content;
                        const btModalRestart = document.getElementById("btModalRestart");
                        if (btModalRestart) { btModalRestart.disabled = false; }
                        toast(translator.tr("msgPswSaved"), "success");
                    } else {
                        toast(translator.tr("errCmdNotExecuted"), "danger");
                    }

                } catch (err) {
                    console.error(err);
                    toast(err);
                } finally {
                    loader(false);
                }
            }

            

      async saveWifi() {
                //this.wifiIP="";
                if(!this.isValidWifi)
                {
                    toast(translator.tr("errSaveWifi"),"warning")
                    return;
                }
                try {
                    this.lockModal("modalSaveWifi", "btCloseSaveWifi1", "btCloseSaveWifi2")
                    const selectedIndex = wifiList.selectedIndex;
                    if (selectedIndex <= 0) { toast(translator.tr("lblSelectWifi"), "warning"); return; }
                    const ssid = wifiList.value;
                    const psw  = document.getElementById("pwd").value;
                    if (!psw) { toast(translator.tr("errPsw"), "warning"); return; }
                    
                    const form = new URLSearchParams();
                    form.append("ssid", ssid);
                    form.append("psw", psw);

                    const res = await sendAPI("conf/save/wifi", {
                        method: "POST",
                        body: form.toString(),
                        return: "text"
                    });

                    if (res === 'ok') {
                        toast(translator.tr("msgPswSaved"), "success");
                    } else {
                        toast(translator.tr("errCmdNotExecuted"), "danger");
                    }

                } catch (err) {
                  
                } 
            }





        refreshObjEvents(mode)
        {
            // --- SCAN ---
            const scanBt = document.getElementById("scanBtn");
            if (scanBt) {
                scanBt.onclick = async () => {
                    loader(true);
                    try {
                        await this.loadLocalWifi();
                    } catch (err) {
                        console.error("Errore scan WiFi:", err);
                        toast(translator.tr("msgScanWifiError"), "danger");
                    }
                    loader(false);
                };
            }

            // --- TEST ---
            const testBtn = document.getElementById("testBtn");
            if (testBtn) {
                testBtn.onclick = async () => {
                    loader(true);
                    try {
                        await this.testConnection();
                    } catch (err) {
                        console.error(err);
                        toast(translator.tr("msgConnectionFailed"), "danger");
                    }
                    loader(false);
                };
            }

            // --- TOGGLE PASSWORD 1 ---
            const toggleBtn = document.getElementById("togglePwd");
            if (toggleBtn) {
                toggleBtn.onclick = () => {
                    const pwd = document.getElementById("pwd");
                    const isHidden = pwd.type === "password";
                    pwd.type = isHidden ? "text" : "password";
                    toggleBtn.textContent = isHidden ? "🙈" : "👁️";
                };
            }

            // --- TOGGLE PASSWORD 2 (AP mode) ---
            const toggleBtn2 = document.getElementById("togglePwd2");
            if (toggleBtn2) {
                toggleBtn2.onclick = () => {
                    const pwd = document.getElementById("pwdAp");
                    const isHidden = pwd.type === "password";
                    pwd.type = isHidden ? "text" : "password";
                    toggleBtn2.textContent = isHidden ? "🙈" : "👁️";
                };
            }

            const txtSsid = document.getElementById("ssidAp");
            if(txtSsid)
            {
                txtSsid.setAttribute("minlength", "4");
                txtSsid.addEventListener('input', () => {
                    const valid = /^[A-Za-z0-9]+$/.test(txtSsid.value);
                    txtSsid.classList.toggle('is-valid', valid);
                    txtSsid.classList.toggle('is-invalid', !valid);
                });
            }
            
            const txtPsw = document.getElementById("pwdAp");
            if (txtPsw)
            {
                txtPsw.setAttribute("minlength", "8");

                txtPsw.addEventListener('input', () => {
                    const valid = (txtPsw.value.length > 7);
                    txtPsw.classList.toggle('is-valid', valid);
                    txtPsw.classList.toggle('is-invalid', !valid);
                });
            }
               


            const btApPsw = document.getElementById("btSaveApPsw");
            if (btApPsw) {
                btApPsw.onclick = async () => {
                    await this.saveAp();
                };
            }

            const modalSaveWifi = document.getElementById('modalSaveWifi');
            if(modalSaveWifi)
            {
                modalSaveWifi.addEventListener('show.bs.modal', () => {
                    const modalBody = document.getElementById("modalBody");
                    if(modalBody)
                    {
                        const hostname = this.wifi.apSsid;
                        let bodyMessage = translator.tr("msgPostWifiSaving");
                        bodyMessage = bodyMessage.replace("@@deviceUrl1@@",`<a href='http://${hostname}.local'>http://${hostname}.local</a>`)
                                                .replace("@@deviceUrl2@@",`<a href='http://${this.wifiIP}'>http://${this.wifiIP}</a>`);
                        modalBody.innerHTML = bodyMessage;
                    }
                });
            }
            

            const modalReset = document.getElementById('modalReset');
            if(modalReset)
            {
                modalReset.addEventListener('show.bs.modal', () => {
                    const modalBody = document.getElementById("modalResetBody");
                    if(modalBody)
                    {
                        modalBody.innerHTML = translator.tr("msg_RESET");
                    }
                });
            }
            
            const modalRestart = document.getElementById('modalRestart');
            if(modalRestart)
            {
                modalRestart.addEventListener('show.bs.modal', () => {
                    const modalBody = document.getElementById("modalRestartBody");
                    if(modalBody)
                    {
                        modalBody.innerHTML = translator.tr("msgApRestart");
                    }
                });
            }


            

            
            const btRestart = document.getElementById("btRestart");
            if (btRestart) {
                btRestart.onclick = async () => {
                    btRestart.disabled = true;
                    await this.restart();
                };
            }
            
            const btReset = document.getElementById("btReset");
            if (btReset) {
                btReset.onclick = async () => {
                    btReset.disabled = true;
                    await this.reset();
                };
            }


            // --- RADIO MODE ---
            const el = document.querySelector(`input[name="modeOptions"][value="${mode}"]`);
            if (el) el.checked = true;

            document.querySelectorAll('input[name="modeOptions"]').forEach(r => {
                r.onchange = () => this.updateWifiForm();
            });
            
            const btnSaveWifi = document.getElementById("btSaveWifi");
            if(btnSaveWifi)
            {
                btnSaveWifi.onclick = async () => {
                    btnSaveWifi.disabled = true;
                    await this.saveWifi();
                };
            }

            const pwd = document.getElementById("pwd");
            if(pwd)
            {
                pwd.addEventListener("input", () => {
                    this.isValidWifi = false;
                    const btModalSaveWifi = document.getElementById("btModalSaveWifi");
                    if(btModalSaveWifi) btModalSaveWifi.disabled = !this.isValidWifi;
                    const statusBox = document.getElementById("wifiTestStatus");
                    if(statusBox) { statusBox.innerHTML = ""; statusBox.className = "mt-1"; }
                });
            }


        }

    async restart() {
        try {
            this.lockModal('modalRestart', "btCancelRestart1", "btCancelRestart2");
           toast(translator.tr("lblRestarting"), "success");
           await fetchAPI("system/restart");
         } catch (err) {
                //console.error(err);
                //
        } finally {
          
        }
    }


    async reset() {
        try {
            this.lockModal('modalReset', "btResetClose1", "btResetClose2");
            toast(translator.tr("lblRestarting"), "success");
            await fetchAPI("conf/reset");
         } catch (err) {
                
            
        } finally {
          
        }
    }

    lockModal(modal_Id, Bt1_Id, Bt2_id)
    {
        const modal = document.getElementById(modal_Id);
         if(modal) { 
                modal.addEventListener('hide.bs.modal', event => {
                    event.preventDefault();
                });
            }
        const bt1 = document.getElementById(Bt1_Id);
        if(bt1)
            {
                bt1.removeAttribute("data-bs-dismiss");        
                bt1.disabled = true;
            } 
        const bt2 = document.getElementById(Bt2_id);
        if(bt2) { 
            bt2.removeAttribute("data-bs-dismiss");
            bt2.disabled = true;
        }
    }


    async testConnection()
    {
        const selectedIndex = wifiList.selectedIndex;

        

        if (selectedIndex <= 0) { toast(translator.tr("lblSelectWifi"), "warning"); return; }
        const ssid = wifiList.value;
        const psw  = document.getElementById("pwd").value;
        if (!psw) { toast(translator.tr("errPsw"), "warning"); return; }
        const statusBox = document.getElementById("wifiTestStatus");
        const lblConnOk = translator.tr("msgConnectionSuccess");
        const lblConnKo = translator.tr("msgConnectionFailed");
        if(statusBox) { statusBox.innerHTML = ""; statusBox.className = "mt-1"; } // reset
        try {
            const result = await this.wifi.testConnAndWait(ssid, psw);
            if (result.status === "Success") { 
                statusBox.innerHTML = `
                <div class="alert alert-success py-1 px-2 mb-0">
                    ${lblConnOk} IP: ${result.ip}
                </div>`;
                this.wifiIP = result.ip;
                this.isValidWifi = true;
                toast( lblConnOk + ` IP: ${result.ip}`, "success"); 
            } else if (result.status === "Failed") 
            { 
                statusBox.innerHTML = `
                <div class="alert alert-danger py-1 px-2 mb-0">
                    ${lblConnKo}
                </div>`;
                this.isValidWifi = false;
                toast(lblConnKo, "error"); 
            }
            const btnSaveWifi = document.getElementById("btModalSaveWifi");
            if(btnSaveWifi) btnSaveWifi.disabled = !this.isValidWifi;

        } catch (err) {
            statusBox.innerHTML = `
                    <div class="alert alert-warning py-1 px-2 mb-0">
                        ${lblConnKo}
                    </div>`;
            toast(lblConnKo, "error"); 
            console.error(err);
        }
         
    }

    async loadLocalWifi() {
       

        try {
            await this.wifi.scanLocalAndWait();
            // Aggiorna la select
            this.refreshLocalWifi();
            toast(translator.tr("msgScanCompleted"), "success");
        } catch (err) {
            console.error("Errore fetch WiFi:", err);
            toast(translator.tr("msgScanWifiError"), "danger");
            
        }
    }

    refreshLocalWifi() {
        const wifiList  = document.getElementById("wifiList");
        if(!wifiList) return;
        const pwdField  = document.getElementById("pwd");
        pwdField.value = this.wifi.wfPsw || "";
        const wfSsid = this.wifi.wfSsid;
        const mode = this.system.getMode();

        if(mode != "AP") //LAN
        {
            let opt = document.createElement("option");
            const rssi = this.wifi.wfRssi;
            opt.value = wfSsid;
            const info = this.getWifiBar(rssi);
            opt.innerHTML = `${wfSsid} <span style="color:${info.color}">(${rssi} dBm)</span> ${info.bar}`;
            opt.dataset.rssi = rssi;
            opt.dataset.color = info.color;
            wifiList.appendChild(opt);
            wifiList.value = wfSsid;

        }
        else { //AP
            const localWifi = this.wifi.localWifi || {};
            if (!localWifi || localWifi.length === 0) {
                    toast(translator.tr("msgNoWifiNet"), "danger");
            }
            wifiList.querySelectorAll("option:not([disabled])").forEach(o => o.remove());
            localWifi.forEach(item => {
                let opt = document.createElement("option");
                opt.value = item.ssid;
                const info = this.getWifiBar(item.rssi);
                // SSID all'inizio, RSSI colorato, barre alla fine
                opt.innerHTML = `${item.ssid} <span style="color:${info.color}">(${item.rssi} dBm)</span> ${info.bar}`;
                opt.dataset.rssi = item.rssi;
                opt.dataset.color = info.color;
                wifiList.appendChild(opt);
            });
            if (wfSsid && wifiList.querySelector(`option[value="${wfSsid}"]`)) { wifiList.value = wfSsid; }
        }

        document.getElementById("wifiList").addEventListener("change", () => {
                this.refreshWifiBadge();
        });
        this.refreshWifiBadge();
    }

    refreshWifiBadge() {
        const wifiSelect = document.getElementById("wifiList");
        const wifiQuality = document.getElementById("wifiQuality");
        if (!wifiSelect || !wifiQuality) return;
        if (wifiSelect.selectedOptions.length === 0) return;
        const selected = wifiSelect.selectedOptions[0];
        const rssi = selected.dataset.rssi ?? "";
        const color = selected.dataset.color ?? "#000";
        wifiQuality.textContent = rssi ? `${rssi} dBm` : "";
        wifiQuality.style.color = color;
    }






     getWifiBar(rssi) {
        let bars = 5; // numero massimo barre
        let level = 0;
        let color = "#999"; // default: grigio
        if (rssi >= -50) { level = 5; color = "#0f0"; }      // verde: ottimo
        else if (rssi >= -60) { level = 4; color = "#8bc34a"; } // verde chiaro: buono
        else if (rssi >= -70) { level = 3; color = "#ffeb3b"; } // giallo: discreto
        else if (rssi >= -80) { level = 2; color = "#ff9800"; } // arancione: debole
        else { level = 1; color = "#f44336"; }                // rosso: molto debole
        // costruisce le barre come quadratini Unicode
        let barStr = "";
        for (let i = 1; i <= bars; i++) {
            if (i <= level) barStr += "■";  // barra piena
            else barStr += "□";             // barra vuota
        }
        // ritorna HTML con colore da applicare in un elemento separato
        return { bar: barStr, color: color };
    }

    
}
