import { translator, registerTimer, setTextContent, sendAPI, system } from './LoopMaxUtils.js';

export class Time {
    constructor(json = {}) {
        this.timezone  = json.timezone  || "";
        this.tz_offset = json.tz_offset || 0;
        this.unix      = json.unix      || 0;
        this.localeMap = { IT: "it-IT", EN: "en-US", ES: "es-ES" };
        registerTimer("time", this.onTick.bind(this));
        const lang = translator.getLanguage(); 
        const locale = this.localeMap[lang] || navigator.language;
    }


     // 🔹 restituisce Date corrente ESP
        nowDate() {
            //return new Date((this.unix + this.tz_offset) * 1000);
            return new Date((this.unix) * 1000);
        }

        formatNow() {
            return this.nowDate().toLocaleString(this.locale);
        }

        formatUnix(unix) {
            return this.fromUnix(unix).toLocaleString(this.locale);
        }



    async checkTime()
    {
        const sys = system();
        if (sys && sys.mode === 'AP') {
                await this.sendTimeInfo();
        }


    }


      async sendTimeInfo() {
                //let unix_utc = Math.floor(Date.now() / 1000);
                const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
                //const offset_sec = -new Date().getTimezoneOffset() * 60;
                const offset_sec = -new Date().getTimezoneOffset() * 60;
                let unix_utc = Math.floor(Date.now() / 1000);
                //unix_utc -= offset_sec;

                /*
                let lat = null, lon = null;
                if (navigator.geolocation) {
                    try {
                        const pos = await new Promise((resolve, reject) => {
                            navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 3000 });
                        });
                        lat = pos.coords.latitude;
                        lon = pos.coords.longitude;
                    } catch (e) {}
                }
                const payload = { unix, tz, tz_offset, lat, lon, source: "client" };
                */
                //const locale = navigator.language;
                //console.log(unix_utc, tz, offset_sec, unix_utc);
                //console.log("Local Time:", new Date(unix_utc * 1000).toLocaleString(locale));

                const form = new URLSearchParams();
                form.append("unix", unix_utc);
                form.append("timezone", tz);
                form.append("offset", offset_sec);

                try {
                    const serverUnix = await sendAPI("time/set", {
                        method: "POST",
                        body: form.toString(),
                        return: "text"
                    });
                    this.unix = Number(serverUnix);
                    this.tz_offset = offset_sec;
                    this.timezone = tz;
                    //return new Date((this.unix - tz_offset) * 1000);
                } catch (err) {
                    console.error(err);
                }
    }



renderCard() {
    registerTimer("time", this.onTick.bind(this));
    
    return `
        <div class="card mt-3 shadow-sm">
            <div class="card-header fw-bold d-flex justify-content-between align-items-center">
                Time Info
            </div>

            <div class="card-body p-3">

                <div class="row mb-2">
                    <div class="col-6"><strong data-tr="lblTimezone"></strong></div>
                    <div class="col-6 text-end">${this.timezone || "-"}</div>
                </div>

                <div class="row mb-2">
                    <div class="col-6"><strong data-tr="lblOffset"></strong></div>
                    <div class="col-6 text-end">${this.tz_offset} sec</div>
                </div>

                <div class="row mb-2">
                    <div class="col-6"><strong data-tr="lblTimeUnix"></strong></div>
                    <div class="col-6 text-end" id="divTimeUnix">${this.unix}</div>
                </div>

                <div class="row">
                    <div class="col-6"><strong data-tr="lblLocalTime"></strong></div>
                    <div class="col-6 text-end" id="divDateTime"></div>
                </div>

            </div>
        </div>
    `;
}


            //onTick(tick) {
                //this.unix++;
                //setTextContent("divTimeUnix", this.unix);

                //const lang = translator.getLanguage(); 
                //const locale = this.localeMap[lang] || navigator.language;
                //const formattedLocal = new Date(this.unix * 1000).toLocaleString(locale);
                //setTextContent("divDateTime", formattedLocal);

                //const sec = this.uptime/1000;
                //setTextContent("divUpTime", `${this.uptime}`);
                // ogni 10 secondi
                /*
                if (tick % 10 === 0) {
                    console.log("Time: sync check");
                }
                */
            //}
            onTick(tick) {
                this.unix++;
                setTextContent("divTimeUnix", this.unix);
                setTextContent("divDateTime", this.formatNow());

            }


            
            
            


}
