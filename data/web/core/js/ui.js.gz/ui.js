// core/UI.js
export class UI {

     static loader(show) {
        const loader = document.getElementById('loadingOverlay');
        if (loader) loader.classList.toggle('d-none', !show);

        // Se mostri lo spinner, pulisci la lista dei messaggi
        if (show) {
            const status = document.getElementById('loadingStatus');
            if (status) status.innerHTML = '';
        }
    }

    static setStatus(message, success = null) {
        const status = document.getElementById('loadingStatus');
        if (!status) return;

        status.textContent = message;

        if (success === true) status.style.color = 'lightgreen';
        else if (success === false) status.style.color = 'salmon';
        else status.style.color = 'white';
    }


    // --- TOASTS (Notifiche) ---
    static toast(message, type = 'info') {
        const container = document.getElementById('toastContainer');
        const id = 'toast_' + Date.now();
        const html = `
            <div id="${id}" class="toast align-items-center text-white bg-${type} border-0" role="alert">
                <div class="d-flex">
                    <div class="toast-body">${message}</div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            </div>`;
        container.insertAdjacentHTML('beforeend', html);
        const el = document.getElementById(id);
        const toast = new bootstrap.Toast(el, { delay: 5000 });
        toast.show();
        el.addEventListener('hidden.bs.toast', () => el.remove());
    }

        // --- BUILDER DI COMPONENTI ---
    static createElement(tag, classes = [], text = "") {
        const el = document.createElement(tag);
        if (classes.length) el.classList.add(...classes);
        if (text) el.innerText = text;
        return el;
    }


    static updateHeader(name, company) {
        const devEl = document.getElementById('devName');
        const compEl = document.getElementById('companyName');
        if (devEl) devEl.innerText = name || "LoopMax";
        if (compEl) compEl.innerText = company || "";
    }



    static buildTabs(ids, labels, contents) {
            const tabList = document.getElementById("configTabs");
            const tabContent = document.getElementById("configTabsContent");

            // Pulisce i tab dinamici precedenti
            tabList.querySelectorAll("li.dynamic-tab").forEach(el => el.remove());
            tabContent.innerHTML = "";

            for (let i = 0; i < ids.length; i++) {
                const id = ids[i];
                const label = labels[i];
                const content = contents[i];
                const isActive = i === 0 ? "active" : "";

                // Tab header
                const li = document.createElement("li");
                li.className = "nav-item dynamic-tab";
                li.role = "presentation";

                const btn = document.createElement("button");
                btn.className = `nav-link secondFont ${isActive}`;
                btn.id = `tabLnk-${id}`;
                btn.dataset.bsToggle = "tab";
                btn.dataset.bsTarget = `#tab-${id}`;
                btn.type = "button";
                btn.role = "tab";
                btn.innerText = label;

                li.appendChild(btn);
                tabList.insertBefore(li, tabList.lastElementChild); // prima del blocco tema/lingua

                // Tab content
                const div = document.createElement("div");
                div.className = `tab-pane fade ${isActive ? "show active" : ""}`;
                div.id = `tab-${id}`;
                div.role = "tabpanel";
                div.innerHTML = content;

                tabContent.appendChild(div);
            }
    }


    
            // ======================== THEMA ==========================
          static initThemeToggle() {
                const btn = document.getElementById("themeToggle");
                const body = document.body;

                let theme = localStorage.getItem("theme") || "light";
                body.setAttribute("data-bs-theme", theme);
                btn.innerHTML = theme === "dark" ? "☀️" : "🌙";

                btn.addEventListener("click", () => {
                    let next = body.getAttribute("data-bs-theme") === "light" ? "dark" : "light";
                    body.setAttribute("data-bs-theme", next);
                    localStorage.setItem("theme", next);
                    btn.innerHTML = next === "dark" ? "☀️" : "🌙";
                });
            }



        static initLanguageSelector(translator) {
                const select = document.getElementById("langSelect");
                if (!select) {
                    console.error("Elemento langSelect non trovato");
                    return;
                }
                try {
                    const langs = translator.getLanguages();
                    select.innerHTML = "";

                    langs.forEach(({ code, label, flag }) => {
                        const opt = document.createElement("option");
                        opt.value = code;
                        opt.textContent = `${flag} ${label}`;
                        select.appendChild(opt);
                    });

                    const savedLng = (localStorage.getItem("lang") ||  "en").toLowerCase();
                    const validCodes = langs.map(l => l.code);
                    const initialLng = validCodes.includes(savedLng) ? savedLng : "en";

                    select.value = initialLng;
                    translator.setLanguage(initialLng);
                    translator.translatePage();

                } catch (err) {
                    console.error("Errore caricamento lingue:", err);
                    toast("Errore caricamento lingue", "danger");
                }

                select.addEventListener("change", async () => {
                    showLoading(true);
                    const lng = select.value;
                    localStorage.setItem("lang", lng);
                    try {
                        const r = await fetch("/savelng?lng=" + lng);
                        const t = await r.text();
                        if (r.status === 200) {
                            toast(t || translator.tr("msgCmdExecuted"), "success");
                            translator.setLanguage(lng);
                            translator.translatePage();
                        } else {
                            toast(t || translator.tr("msgDevErr"), "danger");
                        }
                    } catch (err) {
                        console.error("Fetch error:", err);
                        toast(translator.tr("msgDevErr"), "danger");
                    }
                    showLoading(false);
                });
            }





}